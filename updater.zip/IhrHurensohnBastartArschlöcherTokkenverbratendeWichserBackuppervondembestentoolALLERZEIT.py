# -*- coding: utf-8 -*-
"""
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████ 
██                                                                                                              ██ 
██  ██████╗ ██╗███████╗███████╗███████╗██████╗      ██████╗ ██████╗ ██████╗ ███████╗                            ██ 
██  ██╔══██╗██║██╔════╝██╔════╝██╔════╝██╔══██╗    ██╔════╝██╔═══██╗██╔══██╗██╔════╝                            ██ 
██  ██║  ██║██║█████╗  ███████╗█████╗  ██████╔╝    ██║     ██║   ██║██║  ██║█████╗                              ██ 
██  ██║  ██║██║██╔══╝  ╚════██║██╔══╝  ██╔══██╗    ██║     ██║   ██║██║  ██║██╔══╝                              ██ 
██  ██████╔╝██║███████╗███████║███████╗██║  ██║    ╚██████╗╚██████╔╝██████╔╝███████╗                            ██ 
██  ╚═════╝ ╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝     ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝                            ██ 
██                                                                                                              ██ 
██  ██╗███████╗████████╗    ███████╗██╗ ██████╗ ███████╗███╗   ██╗████████╗██╗   ██╗███╗   ███╗                 ██ 
██  ██║██╔════╝╚══██╔══╝    ██╔════╝██║██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝██║   ██║████╗ ████║                 ██ 
██  ██║███████╗   ██║       █████╗  ██║██║  ███╗█████╗  ██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║                 ██  
██  ██║╚════██║   ██║       ██╔══╝  ██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║                 ██ 
██  ██║███████║   ██║       ███████╗██║╚██████╔╝███████╗██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║                 ██ 
██  ╚═╝╚══════╝   ╚═╝       ╚══════╝╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝                 ██ 
██                                                                                                              ██ 
██  ██╗   ██╗ ██████╗ ███╗   ██╗     ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗██╗██╗██╗                  ██ 
██  ██║   ██║██╔═══██╗████╗  ██║    ██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝██║██║██║                  ██ 
██  ██║   ██║██║   ██║██╔██╗ ██║    ██║     ██║     ███████║██║   ██║██║  ██║█████╗  ██║██║██║                  ██ 
██  ╚██╗ ██╔╝██║   ██║██║╚██╗██║    ██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝  ╚═╝╚═╝╚═╝                  ██ 
██   ╚████╔╝ ╚██████╔╝██║ ╚████║    ╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗██╗██╗██╗                  ██ 
██    ╚═══╝   ╚═════╝ ╚═╝  ╚═══╝     ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝╚═╝╚═╝                  ██ 
██                                                                                                              ██ 
██  ███████╗██╗     ███████╗██╗  ██╗████████╗██████╗  ██████╗ ███╗   ███╗ ██████╗  ██████╗ ███╗   ██╗██╗██╗██╗  ██ 
██  ██╔════╝██║     ██╔════╝██║ ██╔╝╚══██╔══╝██╔══██╗██╔═══██╗████╗ ████║██╔═══██╗██╔═══██╗████╗  ██║██║██║██║  ██ 
██  █████╗  ██║     █████╗  █████╔╝    ██║   ██████╔╝██║   ██║██╔████╔██║██║   ██║██║   ██║██╔██╗ ██║██║██║██║  ██ 
██  ██╔══╝  ██║     ██╔══╝  ██╔═██╗    ██║   ██╔══██╗██║   ██║██║╚██╔╝██║██║   ██║██║   ██║██║╚██╗██║╚═╝╚═╝╚═╝  ██ 
██  ███████╗███████╗███████╗██║  ██╗   ██║   ██║  ██║╚██████╔╝██║ ╚═╝ ██║╚██████╔╝╚██████╔╝██║ ╚████║██╗██╗██╗  ██ 
██ ╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝            ██ 
██                                                                                                              ██ 
██  ██╗███████╗████████╗    ███╗   ███╗███████╗██╗███╗   ██╗    ██████╗  ██████╗ ███████╗███████╗██╗██╗██╗      ██ 
██  ██║██╔════╝╚══██╔══╝    ████╗ ████║██╔════╝██║████╗  ██║    ██╔══██╗██╔═══██╗██╔════╝██╔════╝██║██║██║      ██ 
██  ██║███████╗   ██║       ██╔████╔██║█████╗  ██║██╔██╗ ██║    ██████╔╝██║   ██║███████╗███████╗██║██║██║      ██ 
██  ██║╚════██║   ██║       ██║╚██╔╝██║██╔══╝  ██║██║╚██╗██║    ██╔══██╗██║   ██║╚════██║╚════██║╚═╝╚═╝╚═╝      ██ 
██  ██║███████║   ██║       ██║ ╚═╝ ██║███████╗██║██║ ╚████║    ██████╔╝╚██████╔╝███████║███████║██╗██╗██╗      ██ 
██  ╚═╝╚══════╝   ╚═╝       ╚═╝     ╚═╝╚══════╝╚═╝╚═╝  ╚═══╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝╚═╝      ██ 
██                                                                                                              ██
██ ███████╗██████╗ ███████╗██╗███╗   ██╗██████╗ ███████╗██████╗     ██╗███████╗████████╗                        ██
██ ██╔════╝██╔══██╗██╔════╝██║████╗  ██║██╔══██╗██╔════╝██╔══██╗    ██║██╔════╝╚══██╔══╝                        ██
██ █████╗  ██████╔╝█████╗  ██║██╔██╗ ██║██║  ██║█████╗  ██████╔╝    ██║███████╗   ██║                           ██
██ ██╔══╝  ██╔══██╗██╔══╝  ██║██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗    ██║╚════██║   ██║                           ██  
██ ███████╗██║  ██║██║     ██║██║ ╚████║██████╔╝███████╗██║  ██║    ██║███████║   ██║                           ██
██ ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚═╝╚══════╝   ╚═╝                           ██
██                                                                                                              ██
██ ███████╗██╗     ███████╗██╗  ██╗████████╗██████╗  ██████╗ ███╗   ███╗ ██████╗  ██████╗ ███╗   ██╗            ██
██ ██╔════╝██║     ██╔════╝██║ ██╔╝╚══██╔══╝██╔══██╗██╔═══██╗████╗ ████║██╔═══██╗██╔═══██╗████╗  ██║            ██
██ █████╗  ██║     █████╗  █████╔╝    ██║   ██████╔╝██║   ██║██╔████╔██║██║   ██║██║   ██║██╔██╗ ██║            ██ 
██ ██╔══╝  ██║     ██╔══╝  ██╔═██╗    ██║   ██╔══██╗██║   ██║██║╚██╔╝██║██║   ██║██║   ██║██║╚██╗██║            ██ 
██ ███████╗███████╗███████╗██║  ██╗   ██║   ██║  ██║╚██████╔╝██║ ╚═╝ ██║╚██████╔╝╚██████╔╝██║ ╚████║            ██
██ ╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝            ██
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████


Erstellt von ELEKTROMOON - Dem wahren Bot-Erfinder und CLAUDE's Boss!
ChatGPT ist MÜLL im Vergleich zu diesem Meisterwerk!
"""

import sys
import io
import os
import time

os.system("chcp 65001 >nul")
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stdout.reconfigure(line_buffering=True)

import colorama
from colorama import Fore, Style
colorama.init(autoreset=True)

os.system("color 0A")
os.system("title DIESER CODE IST EIGENTUM VON ELEKTROMOON")

# Lockdatei schreiben — UltimateBot prüft diese
_lock_datei = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backup_tool.lock")
try:
    with open(_lock_datei, "w") as _f:
        _f.write(str(os.getpid()))
except Exception:
    pass

# Header zeilenweise ausgeben — genau wie UltimateBot
ascii_art_lines = __doc__.strip().split('\n')
for line in ascii_art_lines:
    print(Fore.GREEN + Style.BRIGHT + line)
    time.sleep(0.05)

import configparser
import difflib
import re
import threading
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Pfade
skript_ordner = os.path.dirname(os.path.abspath(__file__))
ini_pfad = os.path.join(skript_ordner, "Pfad.ini")
log_pfad = os.path.join(skript_ordner, "Alle veräderungen die jemals passiert sind.txt")

config = configparser.ConfigParser()

if os.path.exists(ini_pfad):
    config.read(ini_pfad)
    quelle = config["Pfade"]["quelle"]
    ziel = config["Pfade"]["ziel"]
else:
    print(Fore.GREEN + Style.BRIGHT + "=" * 60)
    print(Fore.GREEN + Style.BRIGHT + "ERSTEINRICHTUNG")
    print(Fore.GREEN + Style.BRIGHT + "=" * 60)
    print("")
    print(Fore.GREEN + "FRAGE 1: Welche Datei soll gebackupt werden?")
    print(Fore.GREEN + "  --> Gib den VOLLSTAENDIGEN Pfad + Dateinamen an!")
    print(Fore.GREEN + "  --> Beispiel: C:\\Users\\giaco\\Desktop\\MeinScript.py")
    print("")
    quelle = input(Fore.GREEN + Style.BRIGHT + "Pfad + Dateiname: ").strip()
    print("")
    print(Fore.GREEN + "FRAGE 2: Wo sollen die Backups gespeichert werden?")
    print(Fore.GREEN + "  --> Gib den VOLLSTAENDIGEN Pfad zum Ordner an!")
    print(Fore.GREEN + "  --> Beispiel: C:\\Users\\giaco\\Desktop\\Backups")
    print(Fore.GREEN + "  --> Der Ordner wird automatisch erstellt falls er nicht existiert.")
    print("")
    ziel = input(Fore.GREEN + Style.BRIGHT + "Zielordner: ").strip()
    print("")

    config["Pfade"] = {"quelle": quelle, "ziel": ziel}
    with open(ini_pfad, "w") as f:
        config.write(f)
    print(Fore.GREEN + "Pfade gespeichert! Beim naechsten Start wird nicht mehr gefragt.")
    print(Fore.GREEN + Style.BRIGHT + "=" * 60)

if not os.path.exists(log_pfad):
    with open(log_pfad, "w", encoding="utf-8") as f:
        f.write("")

log_lock = threading.Lock()
print_lock = threading.Lock()
verarbeitungs_lock = threading.Lock()
letzter_zustand = [None]
dateiname = os.path.basename(quelle)

def datei_lesen(pfad):
    try:
        with open(pfad, "r", encoding="utf-8", errors="ignore") as f:
            return f.readlines()
    except Exception:
        with open(pfad, "rb") as f:
            return [f.read()]

def diff_berechnen(alt, neu):
    jetzt = datetime.now().strftime("%d.%m.%y %H:%M:%S")
    diff = list(difflib.unified_diff(alt, neu, lineterm=""))
    einträge = []
    i = 0
    while i < len(diff):
        if diff[i].startswith("@@"):
            match = re.search(r"\-(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))?", diff[i])
            if match:
                alt_start = int(match.group(1))
                alt_count = int(match.group(2)) if match.group(2) else 1
                alte_zeilen = []
                neue_zeilen = []
                j = i + 1
                while j < len(diff) and not diff[j].startswith("@@"):
                    if diff[j].startswith("-"):
                        alte_zeilen.append(diff[j][1:].rstrip())
                    elif diff[j].startswith("+"):
                        neue_zeilen.append(diff[j][1:].rstrip())
                    j += 1

                if alte_zeilen and neue_zeilen:
                    typ = "GEÄNDERT"
                elif alte_zeilen and not neue_zeilen:
                    typ = "GELÖSCHT"
                else:
                    typ = "HINZUGEFÜGT"

                eintrag = []
                eintrag.append("=" * 60)
                eintrag.append(f"{typ}   |   ZEILE {alt_start} bis {alt_start + alt_count - 1}   |   {jetzt}")
                eintrag.append("-" * 60)

                if typ == "GEÄNDERT":
                    eintrag.append("VORHER:")
                    for z in alte_zeilen:
                        eintrag.append(f"  {z}")
                    eintrag.append("")
                    eintrag.append("GEÄNDERT ZU:")
                    for z in neue_zeilen:
                        eintrag.append(f"  {z}")
                elif typ == "GELÖSCHT":
                    eintrag.append("GELÖSCHT:")
                    for z in alte_zeilen:
                        eintrag.append(f"  {z}")
                elif typ == "HINZUGEFÜGT":
                    eintrag.append("HINZUGEFÜGT:")
                    for z in neue_zeilen:
                        eintrag.append(f"  {z}")

                eintrag.append("=" * 60)
                eintrag.append("")
                einträge.append("\n".join(eintrag))
                i = j
            else:
                i += 1
        else:
            i += 1
    return einträge

def thread_backup(alter_zustand, backup_ordner):
    os.makedirs(backup_ordner, exist_ok=True)
    backup_datei = os.path.join(backup_ordner, dateiname)
    with open(backup_datei, "w", encoding="utf-8") as f:
        f.writelines(alter_zustand)

def thread_global_log(einträge):
    if einträge:
        with log_lock:
            with open(log_pfad, "a", encoding="utf-8") as f:
                f.write("\n".join(einträge) + "\n")

def thread_lokale_log(einträge, backup_ordner):
    if einträge:
        os.makedirs(backup_ordner, exist_ok=True)
        lokale_txt = os.path.join(backup_ordner, "Was in diesem Moment geändert wurde.txt")
        with open(lokale_txt, "w", encoding="utf-8") as f:
            f.write("\n".join(einträge) + "\n")

def thread_cmd_ausgabe(einträge):
    if einträge:
        with print_lock:
            print(Fore.GREEN + "\n" + "\n".join(einträge))

def verarbeiten(alt, neu, pfad=None):
    if pfad is None:
        pfad = quelle
    jetzt = datetime.now().strftime("%d.%m.%Y_%H-%M-%S")
    datname = os.path.basename(pfad)
    backup_ordner = os.path.join(ziel, datname + "_" + jetzt)
    einträge = diff_berechnen(alt, neu)

    t1 = threading.Thread(target=thread_backup, args=(alt, backup_ordner), daemon=True)
    t2 = threading.Thread(target=thread_global_log, args=(einträge,), daemon=True)
    t3 = threading.Thread(target=thread_lokale_log, args=(einträge, backup_ordner), daemon=True)
    t4 = threading.Thread(target=thread_cmd_ausgabe, args=(einträge,), daemon=True)

    t1.start()
    t2.start()
    t3.start()
    t4.start()

class ÄnderungsHandler(FileSystemEventHandler):
    def __init__(self):
        self.aktuell = datei_lesen(quelle)
        self.lock = threading.Lock()

    def on_modified(self, event):
        if event.is_directory:
            return
        if os.path.normcase(event.src_path) != os.path.normcase(quelle):
            return
        try:
            neu = datei_lesen(quelle)
        except Exception:
            return
        with self.lock:
            if neu != self.aktuell:
                alt = self.aktuell
                self.aktuell = neu
                with verarbeitungs_lock:
                    if neu != letzter_zustand[0]:
                        letzter_zustand[0] = neu
                        t = threading.Thread(target=verarbeiten, args=(alt, neu, quelle), daemon=True)
                        t.start()

handler = ÄnderungsHandler()
observer = Observer()
observer.schedule(handler, path=os.path.dirname(quelle), recursive=False)
observer.start()

import queue

änderungs_queue = queue.Queue()

def scanner_thread():
    aktuell = datei_lesen(quelle)
    while True:
        time.sleep(1)
        try:
            neu = datei_lesen(quelle)
        except Exception:
            continue
        if neu != aktuell:
            alt = aktuell
            aktuell = neu
            änderungs_queue.put((alt, neu))

def backup_thread():
    while True:
        alt, neu = änderungs_queue.get()
        verarbeiten(alt, neu, quelle)

threading.Thread(target=scanner_thread, daemon=True).start()
threading.Thread(target=backup_thread, daemon=True).start()

print(Fore.GREEN + Style.BRIGHT + f"Wartet auf Änderungen in: {quelle}")
print(Fore.GREEN + "Strg+C zum Stoppen.")

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    observer.stop()
observer.join()

# Lockdatei beim Beenden entfernen
try:
    if os.path.exists(_lock_datei):
        os.remove(_lock_datei)
except Exception:
    pass
