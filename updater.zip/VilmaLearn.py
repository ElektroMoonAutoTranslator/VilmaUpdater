import tkinter as tk
from tkinter import messagebox, filedialog
import random
import json
import os
import time
import math
import urllib.request
import urllib.parse
import threading

try:
    import pygame
    pygame.mixer.init()
    PYGAME_OK = True
except Exception:
    PYGAME_OK = False

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.join(BASE_DIR, "audio")
STATS_FILE = os.path.join(BASE_DIR, "VilmaLearn_statistik.json")

# ============================================================
#  Auto-Update (VilmaUpdater Repo auf GitHub)
# ============================================================
VERSION = "1.0.0"
UPDATE_VERSION_URL = "https://raw.githubusercontent.com/ElektroMoonAutoTranslator/VilmaUpdater/main/version.json"

os.makedirs(AUDIO_DIR, exist_ok=True)

# ============================================================
#  Google-Translate TTS (automatische Audio-Erzeugung)
# ============================================================

GTTS_LANGCODE = {"de": "de", "en": "en", "fi": "fi"}

def gtts_dateiname(wort, sprache):
    sicher = "".join(c for c in wort if c.isalnum() or c in (" ", "_", "-")).strip()
    sicher = sicher.replace(" ", "_")
    return f"{sprache}_{sicher}.mp3"

def gtts_herunterladen(text, sprache, ziel_dateiname):
    """Lädt Audio für `text` in `sprache` von Google Translate TTS herunter
    und speichert es unter AUDIO_DIR/ziel_dateiname. Gibt True/False zurück."""
    if not text.strip():
        return False
    lc = GTTS_LANGCODE.get(sprache, sprache)
    ziel_pfad = os.path.join(AUDIO_DIR, ziel_dateiname)
    params = urllib.parse.urlencode({
        "ie": "UTF-8",
        "q": text,
        "tl": lc,
        "client": "tw-ob",
    })
    url = f"https://translate.google.com/translate_tts?{params}"
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36"
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            daten = resp.read()
        if not daten or len(daten) < 100:
            return False
        with open(ziel_pfad, "wb") as f:
            f.write(daten)
        return True
    except Exception:
        return False

# ============================================================
#  Datei-Hilfsfunktionen
# ============================================================

def speicher_pfad(ls):
    return os.path.join(BASE_DIR, f"VilmaLearn_{ls}.json")

def saetze_pfad(ls):
    return os.path.join(BASE_DIR, f"saetze_{ls}.json")

def saetze_laden(ls):
    p = saetze_pfad(ls)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def saetze_speichern(ls, liste):
    with open(saetze_pfad(ls), "w", encoding="utf-8") as f:
        json.dump(liste, f, ensure_ascii=False, indent=2)

def vokabeln_laden(ls):
    p = speicher_pfad(ls)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def vokabeln_speichern(ls, liste):
    with open(speicher_pfad(ls), "w", encoding="utf-8") as f:
        json.dump(liste, f, ensure_ascii=False, indent=2)

def stats_laden():
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE, "r", encoding="utf-8") as f:
            try:
                d = json.load(f)
                if "freigeschaltet" not in d:
                    d["freigeschaltet"] = []
                if "aktiviert" not in d:
                    d["aktiviert"] = []
                return d
            except Exception:
                pass
    return {
        "richtig": 0,
        "falsch": 0,
        "lernzeit_sek": 0,
        "level_xp": 0,
        "wort_stats": {},
        "freigeschaltet": [],
        "aktiviert": [],
    }

def stats_speichern(s):
    with open(STATS_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)

def audio_pfad(dateiname):
    if not dateiname:
        return ""
    if os.path.isabs(dateiname):
        return dateiname
    return os.path.join(AUDIO_DIR, dateiname)

# ============================================================
#  Level-System
# ============================================================

def xp_fuer_level(lvl):
    if lvl <= 1:
        return 0
    return (lvl - 1) * (lvl - 1) * 50

def berechne_level(xp):
    lvl = 1
    while xp >= xp_fuer_level(lvl + 1):
        lvl += 1
    return lvl

def xp_fortschritt(xp):
    lvl = berechne_level(xp)
    xp_aktuell = xp - xp_fuer_level(lvl)
    xp_naechst = xp_fuer_level(lvl + 1) - xp_fuer_level(lvl)
    return lvl, xp_aktuell, xp_naechst

# ============================================================
#  Freischalt-System
# ============================================================

FREISCHALTUNGEN = {
    "de": [
        (3,  "thema_nacht",     "🌙 Nacht-Thema (dunkler Hintergrund)",          "🌙"),
        (5,  "joker",           "🃏 Joker: 1x pro Runde kein XP-Verlust",        "🃏"),
        (7,  "emoji_mode",      "😄 Emoji-Modus: Emojis in der Oberfläche",      "😄"),

        (12, "blitz_modus",     "⚡ Blitz-Modus: 5 Sekunden pro Wort",           "⚡"),
        (15, "mehrfach_wahl",   "🎯 Multiple-Choice-Modus",                      "🎯"),
        (20, "streak_bonus",    "🔥 Streak-Bonus: Doppel-XP bei 5+ in Folge",    "🔥"),
        (25, "xp_multiplikator","💎 XP x1.5 dauerhaft",                          "💎"),
        (30, "marathon_modus",  "🏃 Marathon: unbegrenzte Wörter-Runde",         "🏃"),
        (50, "legende",         "👑 Legende-Abzeichen freigeschaltet",            "👑"),
    ],
    "en": [
        (3,  "thema_nacht",     "🌙 Night Theme (dark background)",               "🌙"),
        (5,  "joker",           "🃏 Joker: 1x per round no XP loss",             "🃏"),
        (7,  "emoji_mode",      "😄 Emoji Mode: emojis in the interface",         "😄"),

        (12, "blitz_modus",     "⚡ Blitz Mode: 5 seconds per word",              "⚡"),
        (15, "mehrfach_wahl",   "🎯 Multiple Choice Mode",                        "🎯"),
        (20, "streak_bonus",    "🔥 Streak Bonus: double XP at 5+ in a row",      "🔥"),
        (25, "xp_multiplikator","💎 XP x1.5 permanently",                         "💎"),
        (30, "marathon_modus",  "🏃 Marathon: unlimited words per round",          "🏃"),
        (50, "legende",         "👑 Legend badge unlocked",                        "👑"),
    ],
    "fi": [
        (3,  "thema_nacht",     "🌙 Yöteema (tumma tausta)",                      "🌙"),
        (5,  "joker",           "🃏 Jokeri: 1x per kierros ilman XP-menetystä",  "🃏"),
        (7,  "emoji_mode",      "😄 Emoji-tila: emojit käyttöliittymässä",        "😄"),

        (12, "blitz_modus",     "⚡ Blitz-tila: 5 sekuntia per sana",             "⚡"),
        (15, "mehrfach_wahl",   "🎯 Monivalintatila",                             "🎯"),
        (20, "streak_bonus",    "🔥 Putki-bonus: tuplat XP 5+ peräkkäisestä",    "🔥"),
        (25, "xp_multiplikator","💎 XP x1.5 pysyvästi",                          "💎"),
        (30, "marathon_modus",  "🏃 Maraton: rajaton sanamäärä kierroksella",     "🏃"),
        (50, "legende",         "👑 Legenda-merkki avattu",                       "👑"),
    ],
}

def get_freigeschaltet(s):
    return set(s.get("freigeschaltet", []))

def get_aktiviert(s):
    return set(s.get("aktiviert", []))

def check_neue_freischaltungen(s, ui="de", root=None):
    xp  = s.get("level_xp", 0)
    lvl = berechne_level(xp)
    bereits = get_freigeschaltet(s)
    neu = []
    for (req_lvl, key, beschr, icon) in FREISCHALTUNGEN[ui]:
        if lvl >= req_lvl and key not in bereits:
            neu.append((key, beschr, icon, req_lvl))
            s["freigeschaltet"].append(key)
    return neu

def hat_freischaltung(key):
    s = stats_laden()
    return key in get_freigeschaltet(s) and key in get_aktiviert(s)

def toggle_aktivierung(key):
    s = stats_laden()
    aktiviert = s.get("aktiviert", [])
    if key in aktiviert:
        aktiviert.remove(key)
        an = False
    else:
        aktiviert.append(key)
        an = True
    s["aktiviert"] = aktiviert
    stats_speichern(s)
    return an

# ============================================================
#  Sprache / Texte
# ============================================================

SPRACH_NATIV = {"de": "Deutsch", "en": "English", "fi": "Suomi"}

SPRACH_NAMEN = {
    "de": {"de": "Deutsch",   "en": "Englisch",  "fi": "Finnisch"},
    "en": {"de": "German",    "en": "English",   "fi": "Finnish"},
    "fi": {"de": "Saksa",     "en": "Englanti",  "fi": "Suomi"},
}
MUTTERSPRACHE_LABEL = {"de": "Deutsch", "en": "English", "fi": "Suomi"}

TEXTE = {
    "de": {
        "lern_frage": "Welche Sprache möchtest du lernen?",
        "saetze": "📝   Ganze Sätze",
        "saetze_titel": "📝  Ganze Sätze",
        "saetze_ein_titel": "➕  Satz eintragen",
        "saetze_lern_titel": "📚   Sätze Lernen",
        "saetze_ein_hinweis": "Satz auf Deutsch oben, Übersetzung unten. Enter oder Speichern.",
        "saetze_ein_label_a": "DEUTSCH",
        "saetze_ein_label_b": "ÜBERSETZUNG ({lang})",
        "saetze_ein_ok": "✓ Satz gespeichert!",
        "saetze_ein_fehler": "⚠ Bitte beide Felder ausfüllen!",
        "saetze_test_titel": "📝  Satz-Test",
        "saetze_test_hinweis": "Groß-/Kleinschreibung & jedes Wort zählt!",
        "saetze_kein": "Bitte zuerst Sätze unter 'Ganze Sätze' hinzufügen!",
        "saetze_kein_titel": "Keine Sätze",
        "saetze_wort_ok": "✓ Wort richtig",
        "saetze_wort_falsch": "✗ Wort falsch",
        "saetze_ergebnis": "Satz-Test abgeschlossen! 🎉\n\nRichtige Wörter: {r} / {g} ({p}%)\nFalsche Wörter: {f}",
        "saetze_gespeichert": "{n} Sätze gespeichert",
        "mix_kurz": "Mix 🔀",
        "titel": "Mein Vokabelheft",
        "lernsprache": "Lernsprache: {lang}",
        "gespeichert": "{n} Vokabeln gespeichert",
        "eintragen": "✏️   Eintragen",
        "lernen": "📚   Lernen",
        "test": "🧪   Test",
        "bearbeiten": "🔧   Bearbeiten",
        "statistik": "📊   Statistik",
        "freischaltungen": "🏆   Freischaltungen",
        "zurueck": "← Zurück",
        "weiter": "Weiter →",
        "speichern": "💾  Speichern",
        "sprache_aendern": "Sprache / Lernsprache ändern",
        "richtung_titel": "Richtung wählen",
        "richtung_normal_kurz": "Normal",
        "richtung_umgekehrt_kurz": "Umgekehrt 🔄",
        "richtung_gemischt_kurz": "Gemischt 🔀",
        "ein_titel": "✏️  Vokabel eintragen",
        "ein_hinweis": "Felder ausfüllen und Enter drücken oder auf Speichern klicken.",
        "ein_label_b": "LERNSPRACHE ({lang})",
        "ein_fehler": "⚠  Bitte beide Felder ausfüllen!",
        "ein_ok": "✓  '{w}' gespeichert!",
        "lern_titel": "📚  Lernen",
        "lern_titel_r": "📚  Lernen 🔄",
        "lern_hinweis": "H drücken oder auf das Kästchen klicken → aufdecken/verstecken",
        "lern_karte": "Karte {i} von {n}",
        "lern_versteckt": "❓  H drücken zum Aufdecken",
        "lern_fertig": "Du hast alle {n} Vokabeln durchgelernt! 🎉",
        "lern_vorherige": "← Vorherige",
        "test_titel": "🧪  Test",
        "test_titel_r": "🧪  Test 🔄",
        "test_titel_g": "🔀  Gemischter Test",
        "test_frage": "Frage {i} von {n}",
        "test_versuche": "Versuche übrig: {v}",
        "test_label_b": "LERNSPRACHE EINGEBEN ({lang})",
        "test_richtig": "✓  Richtig!",
        "test_falsch_n": "✗  Falsch! Noch {v} Versuch{e}",
        "test_falsch_end": "✗  Leider falsch!",
        "test_3x": "❌  3 mal falsch!",
        "test_loesung": "Die richtige Antwort ist:",
        "test_ergebnis": "Test abgeschlossen! 🎉\n\nRichtig: {r} / {g}  ({p}%)\nFalsch: {f}",
        "test_prufen": "Prüfen ✓",
        "lern_play": "▶  Audio",
        "test_play": "▶  Audio",
        "test_kein_audio": "Kein Audio für dieses Wort.\n\nAudio-Dateien bitte in den Ordner:\n{folder}",
        "joker_btn": "🃏 Joker nutzen",
        "joker_genutzt": "🃏 Joker bereits genutzt",
        "joker_angewendet": "🃏 Joker! Kein XP-Verlust.",
        "bear_titel": "🔧  Bearbeiten",
        "bear_suche": "🔍  Suchen...",
        "bear_leer": "Noch keine Vokabeln gespeichert.",
        "bear_keine_treffer": "Keine Treffer für '{q}'.",
        "bear_col_b": "Lernsprache",
        "bear_aktion": "Aktion",
        "bear_aendern": "Ändern",
        "bear_loeschen": "Löschen",
        "bear_dlg_titel": "Vokabel ändern",
        "bear_dlg_b": "Lernsprache ({lang}):",
        "bear_dlg_audio": "Audio-Datei (mp3) aus audio/-Ordner:",
        "bear_dlg_audio_btn": "Datei wählen",
        "bear_dlg_save": "Speichern",
        "bear_dlg_abbruch": "Abbrechen",
        "bear_del_frage": "'{w}' wirklich löschen?",
        "bear_del_titel": "Löschen",
        "keine_vok": "Bitte zuerst Vokabeln unter 'Eintragen' hinzufügen!",
        "keine_titel": "Keine Vokabeln",
        "stat_titel": "📊  Statistik",
        "stat_richtig": "Richtig beantwortet",
        "stat_falsch": "Falsch beantwortet",
        "stat_genauigkeit": "Genauigkeit",
        "stat_lernzeit": "Lernzeit gesamt",
        "stat_level": "Level",
        "stat_xp": "XP",
        "stat_naechstes": "Nächstes Level",
        "stat_top_falsch": "Häufigste Fehler",
        "stat_keine": "Noch keine Daten.",
        "stat_min": "Min.",
        "stat_std": "Std.",
        "lvl_titel": "🎯  Level-Modus",
        "lvl_hint": "Wie viel Prozent der Vokabeln möchtest du üben?",
        "lvl_prozent": "Prozent (1–100):",
        "lvl_schwach": "⚡  Schwächste Wörter zuerst",
        "lvl_zufall": "🎲  Zufällige Auswahl",
        "lvl_start": "Start",
        "lvl_fehler": "Bitte eine Zahl zwischen 1 und 100 eingeben.",
        "blitz_titel": "⚡  Blitz-Modus",
        "blitz_zeit": "Zeit: {s}s",
        "blitz_abgelaufen": "⏰ Zeit abgelaufen!",
        "mc_titel": "🎯  Multiple Choice",
        "freisch_titel": "🏆  Freischaltungen",
        "freisch_gesperrt": "🔒  Gesperrt (Level {lvl} nötig)",
        "freisch_frei": "✅  Freigeschaltet",
        "freisch_an": "🟢  AN",
        "freisch_aus": "⚫  AUS",
        "freisch_aktivieren": "Aktivieren",
        "freisch_deaktivieren": "Deaktivieren",
        "level_auf": "🎉 Level {lvl} erreicht!\n\nFreigeschaltet:",
        "streak": "🔥 {n}x in Folge!",
        "xp_verlust": "-{xp} XP",
        "xp_gewinn": "+{xp} XP",
        "saetze_bear_titel": "🔧  Sätze bearbeiten",
        "saetze_bear_btn": "🔧   Sätze bearbeiten",
        "saetze_bear_aendern": "Ändern",
        "saetze_bear_loeschen": "Löschen",
        "saetze_bear_aendern_titel": "Satz ändern",
        "saetze_bear_audio": "Audio-Datei (mp3) aus audio/-Ordner:",
        "saetze_bear_audio_btn": "Datei wählen",
        "saetze_bear_speichern": "💾  Speichern",
        "saetze_bear_abbruch": "Abbrechen",
        "saetze_bear_loeschen_frage": "'{w}' wirklich löschen?",
        "saetze_bear_loeschen_titel": "Löschen",
        "saetze_bear_leer": "Noch keine Sätze gespeichert.",
        "saetze_bear_aktion": "Aktion",
        "satz_test_prufen": "Prüfen ✓",
        "satz_test_audio": "▶  Audio",
        "satz_test_kein_audio": "Kein Audio für diesen Satz.\n\nAudio-Dateien bitte in den Ordner:\n{folder}",
        "satz_fb_titel": "WORT-FÜR-WORT AUSWERTUNG",
        "satz_vers_uebrig": "Versuche: {v} übrig",
        "satz_vers_fehler": "⚠ {f} Fehler  –  noch {v} Versuch{e}",
        "satz_vers_perfekt": "✅ Perfekt nach {v} Versuch{e}!",
        "satz_vers_auf": "❌ Versuche aufgebraucht! Lösung:",
        "vok_menue_titel": "📖   Vokabeln",
    },
    "en": {
        "lern_frage": "Which language do you want to learn?",
        "saetze": "📝   Full Sentences",
        "saetze_titel": "📝  Full Sentences",
        "saetze_ein_titel": "➕  Add Sentence",
        "saetze_lern_titel": "📚   Learn Sentences",
        "saetze_ein_hinweis": "Sentence in your language above, translation below. Enter or Save.",
        "saetze_ein_label_a": "YOUR LANGUAGE",
        "saetze_ein_label_b": "TRANSLATION ({lang})",
        "saetze_ein_ok": "✓ Sentence saved!",
        "saetze_ein_fehler": "⚠ Please fill in both fields!",
        "saetze_test_titel": "📝  Sentence Test",
        "saetze_test_hinweis": "Case-sensitive & every word counts!",
        "saetze_kein": "Please add sentences in 'Full Sentences' first!",
        "saetze_kein_titel": "No Sentences",
        "saetze_wort_ok": "✓ Word correct",
        "saetze_wort_falsch": "✗ Word wrong",
        "saetze_ergebnis": "Sentence test done! 🎉\n\nCorrect words: {r} / {g} ({p}%)\nWrong words: {f}",
        "saetze_gespeichert": "{n} sentences saved",
        "mix_kurz": "Mix 🔀",
        "titel": "My Vocabulary Book",
        "lernsprache": "Learning: {lang}",
        "gespeichert": "{n} words saved",
        "eintragen": "✏️   Add Words",
        "lernen": "📚   Study",
        "test": "🧪   Test",
        "bearbeiten": "🔧   Edit",
        "statistik": "📊   Statistics",
        "freischaltungen": "🏆   Unlocks",
        "zurueck": "← Back",
        "weiter": "Next →",
        "speichern": "💾  Save",
        "sprache_aendern": "Change language / learning language",
        "richtung_titel": "Choose direction",
        "richtung_normal_kurz": "Normal",
        "richtung_umgekehrt_kurz": "Reversed 🔄",
        "richtung_gemischt_kurz": "Mixed 🔀",
        "ein_titel": "✏️  Add a Word",
        "ein_hinweis": "Fill in both fields and press Enter or click Save.",
        "ein_label_b": "LEARNING LANGUAGE ({lang})",
        "ein_fehler": "⚠  Please fill in both fields!",
        "ein_ok": "✓  '{w}' saved!",
        "lern_titel": "📚  Study",
        "lern_titel_r": "📚  Study 🔄",
        "lern_hinweis": "Press H or click the box → reveal / hide word",
        "lern_karte": "Card {i} of {n}",
        "lern_versteckt": "❓  Press H to reveal",
        "lern_fertig": "You studied all {n} words! 🎉",
        "lern_vorherige": "← Previous",
        "test_titel": "🧪  Test",
        "test_titel_r": "🧪  Test 🔄",
        "test_titel_g": "🔀  Mixed Test",
        "test_frage": "Question {i} of {n}",
        "test_versuche": "Attempts left: {v}",
        "test_label_b": "ENTER LEARNING LANGUAGE ({lang})",
        "test_richtig": "✓  Correct!",
        "test_falsch_n": "✗  Wrong! {v} attempt{e} left",
        "test_falsch_end": "✗  Incorrect!",
        "test_3x": "❌  3 times wrong!",
        "test_loesung": "The correct answer is:",
        "test_ergebnis": "Test finished! 🎉\n\nCorrect: {r} / {g}  ({p}%)\nWrong: {f}",
        "test_prufen": "Check ✓",
        "lern_play": "▶  Audio",
        "test_play": "▶  Audio",
        "test_kein_audio": "No audio for this word.\n\nPlace audio files in:\n{folder}",
        "joker_btn": "🃏 Use Joker",
        "joker_genutzt": "🃏 Joker already used",
        "joker_angewendet": "🃏 Joker! No XP loss.",
        "bear_titel": "🔧  Edit",
        "bear_suche": "🔍  Search...",
        "bear_leer": "No words saved yet.",
        "bear_keine_treffer": "No results for '{q}'.",
        "bear_col_b": "Learning",
        "bear_aktion": "Action",
        "bear_aendern": "Edit",
        "bear_loeschen": "Delete",
        "bear_dlg_titel": "Edit Word",
        "bear_dlg_b": "Learning language ({lang}):",
        "bear_dlg_audio": "Audio file (mp3) from audio/ folder:",
        "bear_dlg_audio_btn": "Choose file",
        "bear_dlg_save": "Save",
        "bear_dlg_abbruch": "Cancel",
        "bear_del_frage": "Really delete '{w}'?",
        "bear_del_titel": "Delete",
        "keine_vok": "Please add words in 'Add Words' first!",
        "keine_titel": "No Words",
        "stat_titel": "📊  Statistics",
        "stat_richtig": "Correct answers",
        "stat_falsch": "Wrong answers",
        "stat_genauigkeit": "Accuracy",
        "stat_lernzeit": "Total study time",
        "stat_level": "Level",
        "stat_xp": "XP",
        "stat_naechstes": "Next level",
        "stat_top_falsch": "Most frequent mistakes",
        "stat_keine": "No data yet.",
        "stat_min": "min",
        "stat_std": "h",
        "lvl_titel": "🎯  Level Mode",
        "lvl_hint": "What percentage of words do you want to practice?",
        "lvl_prozent": "Percent (1–100):",
        "lvl_schwach": "⚡  Weakest words first",
        "lvl_zufall": "🎲  Random selection",
        "lvl_start": "Start",
        "lvl_fehler": "Please enter a number between 1 and 100.",
        "blitz_titel": "⚡  Blitz Mode",
        "blitz_zeit": "Time: {s}s",
        "blitz_abgelaufen": "⏰ Time's up!",
        "mc_titel": "🎯  Multiple Choice",
        "freisch_titel": "🏆  Unlocks",
        "freisch_gesperrt": "🔒  Locked (need Level {lvl})",
        "freisch_frei": "✅  Unlocked",
        "freisch_an": "🟢  ON",
        "freisch_aus": "⚫  OFF",
        "freisch_aktivieren": "Activate",
        "freisch_deaktivieren": "Deactivate",
        "level_auf": "🎉 Reached Level {lvl}!\n\nUnlocked:",
        "streak": "🔥 {n}x in a row!",
        "xp_verlust": "-{xp} XP",
        "xp_gewinn": "+{xp} XP",
        "saetze_bear_titel": "🔧  Edit Sentences",
        "saetze_bear_btn": "🔧   Edit Sentences",
        "saetze_bear_aendern": "Edit",
        "saetze_bear_loeschen": "Delete",
        "saetze_bear_aendern_titel": "Edit Sentence",
        "saetze_bear_audio": "Audio file (mp3) from audio/ folder:",
        "saetze_bear_audio_btn": "Choose file",
        "saetze_bear_speichern": "💾  Save",
        "saetze_bear_abbruch": "Cancel",
        "saetze_bear_loeschen_frage": "Really delete '{w}'?",
        "saetze_bear_loeschen_titel": "Delete",
        "saetze_bear_leer": "No sentences saved yet.",
        "saetze_bear_aktion": "Action",
        "satz_test_prufen": "Check ✓",
        "satz_test_audio": "▶  Audio",
        "satz_test_kein_audio": "No audio for this sentence.\n\nPlace audio files in:\n{folder}",
        "satz_fb_titel": "WORD-BY-WORD EVALUATION",
        "satz_vers_uebrig": "Attempts: {v} left",
        "satz_vers_fehler": "⚠ {f} error(s)  –  {v} attempt{e} left",
        "satz_vers_perfekt": "✅ Perfect after {v} attempt{e}!",
        "satz_vers_auf": "❌ Attempts used up! Solution:",
        "vok_menue_titel": "📖   Vocabulary",
    },
    "fi": {
        "lern_frage": "Minkä kielen haluat oppia?",
        "saetze": "📝   Kokonaiset lauseet",
        "saetze_titel": "📝  Kokonaiset lauseet",
        "saetze_ein_titel": "➕  Lisää lause",
        "saetze_lern_titel": "📚   Opettele lauseita",
        "saetze_ein_hinweis": "Lause ylhäällä, käännös alhaalla. Enter tai Tallenna.",
        "saetze_ein_label_a": "OMA KIELI",
        "saetze_ein_label_b": "KÄÄNNÖS ({lang})",
        "saetze_ein_ok": "✓ Lause tallennettu!",
        "saetze_ein_fehler": "⚠ Täytä molemmat kentät!",
        "saetze_test_titel": "📝  Lausetesti",
        "saetze_test_hinweis": "Kirjainkoolla on väliä & jokainen sana lasketaan!",
        "saetze_kein": "Lisää ensin lauseita 'Kokonaiset lauseet' -osiossa!",
        "saetze_kein_titel": "Ei lauseita",
        "saetze_wort_ok": "✓ Sana oikein",
        "saetze_wort_falsch": "✗ Sana väärin",
        "saetze_ergebnis": "Lausetesti valmis! 🎉\n\nOikeat sanat: {r} / {g} ({p}%)\nVäärät sanat: {f}",
        "saetze_gespeichert": "{n} lausetta tallennettu",
        "mix_kurz": "Mix 🔀",
        "titel": "Sanastovihkoni",
        "lernsprache": "Opiskelukieli: {lang}",
        "gespeichert": "{n} sanaa tallennettu",
        "eintragen": "✏️   Lisää sanoja",
        "lernen": "📚   Opiskele",
        "test": "🧪   Testi",
        "bearbeiten": "🔧   Muokkaa",
        "statistik": "📊   Tilastot",
        "freischaltungen": "🏆   Saavutukset",
        "zurueck": "← Takaisin",
        "weiter": "Seuraava →",
        "speichern": "💾  Tallenna",
        "sprache_aendern": "Vaihda kieltä / opiskelukieltä",
        "richtung_titel": "Valitse suunta",
        "richtung_normal_kurz": "Normaali",
        "richtung_umgekehrt_kurz": "Käänteinen 🔄",
        "richtung_gemischt_kurz": "Sekalainen 🔀",
        "ein_titel": "✏️  Lisää sana",
        "ein_hinweis": "Täytä molemmat kentät ja paina Enter tai Tallenna.",
        "ein_label_b": "OPISKELUKIELI ({lang})",
        "ein_fehler": "⚠  Täytä molemmat kentät!",
        "ein_ok": "✓  '{w}' tallennettu!",
        "lern_titel": "📚  Opiskele",
        "lern_titel_r": "📚  Opiskele 🔄",
        "lern_hinweis": "Paina H tai klikkaa ruutua → näytä / piilota sana",
        "lern_karte": "Kortti {i} / {n}",
        "lern_versteckt": "❓  Paina H näyttääksesi",
        "lern_fertig": "Olet opiskellut kaikki {n} sanaa! 🎉",
        "lern_vorherige": "← Edellinen",
        "test_titel": "🧪  Testi",
        "test_titel_r": "🧪  Testi 🔄",
        "test_titel_g": "🔀  Sekalainen testi",
        "test_frage": "Kysymys {i} / {n}",
        "test_versuche": "Yrityksiä jäljellä: {v}",
        "test_label_b": "KIRJOITA OPISKELUKIELELLÄ ({lang})",
        "test_richtig": "✓  Oikein!",
        "test_falsch_n": "✗  Väärin! {v} yritys{e} jäljellä",
        "test_falsch_end": "✗  Väärin!",
        "test_3x": "❌  3 kertaa väärin!",
        "test_loesung": "Oikea vastaus on:",
        "test_ergebnis": "Testi valmis! 🎉\n\nOikein: {r} / {g}  ({p}%)\nVäärin: {f}",
        "test_prufen": "Tarkista ✓",
        "lern_play": "▶  Audio",
        "test_play": "▶  Audio",
        "test_kein_audio": "Ei ääntä tälle sanalle.\n\nLisää äänitiedostot kansioon:\n{folder}",
        "joker_btn": "🃏 Käytä jokeri",
        "joker_genutzt": "🃏 Jokeri käytetty",
        "joker_angewendet": "🃏 Jokeri! Ei XP-menetystä.",
        "bear_titel": "🔧  Muokkaa",
        "bear_suche": "🔍  Etsi...",
        "bear_leer": "Ei tallennettuja sanoja.",
        "bear_keine_treffer": "Ei tuloksia haulle '{q}'.",
        "bear_col_b": "Opiskelukieli",
        "bear_aktion": "Toiminto",
        "bear_aendern": "Muokkaa",
        "bear_loeschen": "Poista",
        "bear_dlg_titel": "Muokkaa sanaa",
        "bear_dlg_b": "Opiskelukieli ({lang}):",
        "bear_dlg_audio": "Äänitiedosto (mp3) audio/-kansiosta:",
        "bear_dlg_audio_btn": "Valitse tiedosto",
        "bear_dlg_save": "Tallenna",
        "bear_dlg_abbruch": "Peruuta",
        "bear_del_frage": "Poistetaanko '{w}'?",
        "bear_del_titel": "Poista",
        "keine_vok": "Lisää ensin sanoja 'Lisää sanoja' -osiossa!",
        "keine_titel": "Ei sanoja",
        "stat_titel": "📊  Tilastot",
        "stat_richtig": "Oikein vastattu",
        "stat_falsch": "Väärin vastattu",
        "stat_genauigkeit": "Tarkkuus",
        "stat_lernzeit": "Opiskeluaika yhteensä",
        "stat_level": "Taso",
        "stat_xp": "XP",
        "stat_naechstes": "Seuraava taso",
        "stat_top_falsch": "Yleisimmät virheet",
        "stat_keine": "Ei vielä tietoja.",
        "stat_min": "min",
        "stat_std": "h",
        "lvl_titel": "🎯  Taso-tila",
        "lvl_hint": "Kuinka suuren osan sanoista haluat harjoitella?",
        "lvl_prozent": "Prosentti (1–100):",
        "lvl_schwach": "⚡  Heikoimmista sanoista",
        "lvl_zufall": "🎲  Satunnainen valinta",
        "lvl_start": "Aloita",
        "lvl_fehler": "Anna luku välillä 1–100.",
        "blitz_titel": "⚡  Blitz-tila",
        "blitz_zeit": "Aika: {s}s",
        "blitz_abgelaufen": "⏰ Aika loppui!",
        "mc_titel": "🎯  Monivalinta",
        "freisch_titel": "🏆  Saavutukset",
        "freisch_gesperrt": "🔒  Lukittu (tarvitset tason {lvl})",
        "freisch_frei": "✅  Avattu",
        "freisch_an": "🟢  PÄÄLLÄ",
        "freisch_aus": "⚫  POIS",
        "freisch_aktivieren": "Aktivoi",
        "freisch_deaktivieren": "Poista käytöstä",
        "level_auf": "🎉 Taso {lvl} saavutettu!\n\nAvattu:",
        "streak": "🔥 {n}x peräkkäin!",
        "xp_verlust": "-{xp} XP",
        "xp_gewinn": "+{xp} XP",
        "saetze_bear_titel": "🔧  Muokkaa lauseita",
        "saetze_bear_btn": "🔧   Muokkaa lauseita",
        "saetze_bear_aendern": "Muokkaa",
        "saetze_bear_loeschen": "Poista",
        "saetze_bear_aendern_titel": "Muokkaa lausetta",
        "saetze_bear_audio": "Äänitiedosto (mp3) audio/-kansiosta:",
        "saetze_bear_audio_btn": "Valitse tiedosto",
        "saetze_bear_speichern": "💾  Tallenna",
        "saetze_bear_abbruch": "Peruuta",
        "saetze_bear_loeschen_frage": "Poistetaanko '{w}'?",
        "saetze_bear_loeschen_titel": "Poista",
        "saetze_bear_leer": "Ei tallennettuja lauseita.",
        "saetze_bear_aktion": "Toiminto",
        "satz_test_prufen": "Tarkista ✓",
        "satz_test_audio": "▶  Audio",
        "satz_test_kein_audio": "Ei ääntä tälle lauseelle.\n\nLisää äänitiedostot kansioon:\n{folder}",
        "satz_fb_titel": "SANA-SANA ARVIOINTI",
        "satz_vers_uebrig": "Yrityksiä: {v} jäljellä",
        "satz_vers_fehler": "⚠ {f} virhe(ttä)  –  {v} yritys{e} jäljellä",
        "satz_vers_perfekt": "✅ Täydellinen {v} yrityksen{e} jälkeen!",
        "satz_vers_auf": "❌ Yritykset loppu! Vastaus:",
        "vok_menue_titel": "📖   Sanasto",
    },
}

def t(ui, key, **kw):
    txt = TEXTE[ui].get(key, key)
    return txt.format(**kw) if kw else txt

def langname(ui, code):
    return SPRACH_NAMEN[code][ui]

def nativname(code):
    return SPRACH_NATIV[code]

def muttersprache_label(ui):
    return MUTTERSPRACHE_LABEL[ui]

# ============================================================
#  Farben
# ============================================================

CLR_LIGHT = {
    "bg":         "#f0f2f5",
    "white":      "white",
    "border":     "#dde3ea",
    "blue":       "#3498db",
    "green":      "#2ecc71",
    "orange":     "#e67e22",
    "purple":     "#9b59b6",
    "red":        "#e74c3c",
    "gray":       "#ecf0f1",
    "text":       "#2c3e50",
    "sub":        "#888",
    "light":      "#eef0f3",
    "xp":         "#f39c12",
    "card":       "white",
    "row_a":      "white",
    "row_b":      "#f7f9fc",
    "entry_bg":   "white",
    "entry_fg":   "#2c3e50",
    "entry_ins":  "#2c3e50",
    "card_border":"black",
    "back_bg":    "white",
    "back_fg":    "#222222",
    "hdr_bg":     "black",
    "hdr_fg":     "white",
    "popup_bg":   "white",
    "popup_fg":   "#2c3e50",
}

CLR_DARK = {
    "bg":         "#1a1a2e",
    "white":      "#16213e",
    "border":     "#4a5568",
    "blue":       "#4a9fd4",
    "green":      "#27ae60",
    "orange":     "#e67e22",
    "purple":     "#9b59b6",
    "red":        "#e74c3c",
    "gray":       "#2d2d44",
    "text":       "#ffffff",
    "sub":        "#cccccc",
    "light":      "#1e1e35",
    "xp":         "#f39c12",
    "card":       "#16213e",
    "row_a":      "#16213e",
    "row_b":      "#1e1e35",
    "entry_bg":   "#0f3460",
    "entry_fg":   "#ffffff",
    "entry_ins":  "#ffffff",
    "card_border":"#ffffff",
    "back_bg":    "#2d2d44",
    "back_fg":    "#ffffff",
    "hdr_bg":     "#0f3460",
    "hdr_fg":     "#ffffff",
    "popup_bg":   "#16213e",
    "popup_fg":   "#ffffff",
}

CLR = CLR_LIGHT.copy()

def make_frame(parent, **kw):
    return tk.Frame(parent, bg=CLR["bg"], **kw)

# ============================================================
#  Skalierung (Fenster frei groessenveraenderbar)
# ============================================================

class _Skalierung:
    def __init__(self):
        self.basis_w = 460
        self.basis_h = 560
        self.faktor  = 1.0

    def setze_basis(self, w, h):
        self.basis_w = max(1, w)
        self.basis_h = max(1, h)
        self.faktor  = 1.0

    def aktualisiere(self, w, h):
        if self.basis_w <= 0 or self.basis_h <= 0:
            return
        f = min(w / self.basis_w, h / self.basis_h)
        self.faktor = max(0.6, min(2.2, f))

    def s(self, wert):
        if wert == 0:
            return 0
        ergebnis = int(round(wert * self.faktor))
        return ergebnis if ergebnis != 0 else (1 if wert > 0 else -1)

SKAL = _Skalierung()

def fnt(size, *stil):
    return ("Arial", SKAL.s(size)) + stil

# ============================================================
#  App
# ============================================================

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("VilmaLearn 1.0")
        try:
            self.root.iconbitmap(os.path.join(BASE_DIR, "heart.ico"))
        except Exception:
            pass
        self.root.resizable(True, True)
        self.root.minsize(320, 280)
        self.root.configure(bg=CLR["bg"])
        self.ui  = None
        self.ls  = None
        self._session_start = None
        self._aktuelle_ansicht = None
        self._resize_after = None
        s = stats_laden()
        if hat_freischaltung("thema_nacht"):
            CLR.update(CLR_DARK)
            self.root.configure(bg=CLR["bg"])
        self._export_txt()
        self.root.protocol("WM_DELETE_WINDOW", self._beim_schliessen)
        self.root.bind("<Configure>", self._on_resize)
        self.zeige_ui_auswahl()

    def _on_resize(self, event):
        if event.widget is not self.root:
            return
        if self._resize_after:
            self.root.after_cancel(self._resize_after)
        self._resize_after = self.root.after(120, self._resize_anwenden)

    def _resize_anwenden(self):
        self._resize_after = None
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        alt = SKAL.faktor
        SKAL.aktualisiere(w, h)
        if abs(SKAL.faktor - alt) >= 0.03 and self._aktuelle_ansicht:
            ansicht = self._aktuelle_ansicht
            self._aktuelle_ansicht = None
            ansicht()
            self._aktuelle_ansicht = ansicht

    def _beim_schliessen(self):
        self._session_beenden()
        self._export_txt()
        self.root.destroy()

    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()
        self.root.unbind("<Return>")
        self.root.unbind("<h>")
        self.root.unbind("<H>")
        try:
            self.root.unbind_all("<MouseWheel>")
        except Exception:
            pass
        if hasattr(self, '_blitz_after') and self._blitz_after:
            self.root.after_cancel(self._blitz_after)
            self._blitz_after = None

    def _session_starten(self):
        self._session_start = time.time()

    def _session_beenden(self):
        if self._session_start:
            sek = int(time.time() - self._session_start)
            s = stats_laden()
            s["lernzeit_sek"] = s.get("lernzeit_sek", 0) + sek
            stats_speichern(s)
            self._session_start = None
        self._export_txt()

    def _export_txt(self):
        pfad = os.path.join(BASE_DIR, "vokabeln_export.txt")
        sprachen = ["de", "en", "fi"]
        sprach_namen = {"de": "Deutsch", "en": "Englisch", "fi": "Finnisch"}
        try:
            with open(pfad, "w", encoding="utf-8") as f:
                f.write("=" * 60 + "\n")
                f.write("  VOKABELHEFT  —  EXPORT\n")
                f.write(f"  Stand: {__import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n")
                f.write("=" * 60 + "\n\n")
                reihenfolge = ["de", "fi"] + [s for s in sprachen if s not in ("de", "fi")]
                f.write("═" * 60 + "\n")
                f.write("  WÖRTER\n")
                f.write("═" * 60 + "\n\n")
                for ls in reihenfolge:
                    vok = vokabeln_laden(ls)
                    if not vok:
                        continue
                    f.write(f"─" * 60 + "\n")
                    f.write(f"  Lernsprache: {sprach_namen.get(ls, ls)}\n")
                    f.write(f"─" * 60 + "\n")
                    for i, v in enumerate(sorted(vok, key=lambda x: x.get('nativ','').lower()), 1):
                        audio_info = f"  [🎵 {v['audio']}]" if v.get('audio') else ""
                        f.write(f"  {i:>3}. Deutsch:  {v.get('nativ', '')}\n")
                        f.write(f"       {sprach_namen.get(ls,ls)+':':10} {v.get('lern', '')}{audio_info}\n")
                    f.write(f"\n  Gesamt: {len(vok)} Wörter\n\n")
                f.write("═" * 60 + "\n")
                f.write("  SÄTZE\n")
                f.write("═" * 60 + "\n\n")
                for ls in reihenfolge:
                    saetze = saetze_laden(ls)
                    if not saetze:
                        continue
                    f.write(f"─" * 60 + "\n")
                    f.write(f"  Lernsprache: {sprach_namen.get(ls, ls)}\n")
                    f.write(f"─" * 60 + "\n")
                    for i, s in enumerate(saetze, 1):
                        audio_info = f"  [🎵 {s['audio']}]" if s.get('audio') else ""
                        f.write(f"  {i:>3}. Deutsch:  {s.get('nativ', '')}\n")
                        f.write(f"       {sprach_namen.get(ls,ls)+':':10} {s.get('lern', '')}{audio_info}\n")
                    f.write(f"\n  Gesamt: {len(saetze)} Sätze\n\n")
                f.write("=" * 60 + "\n")
                f.write("  ENDE DES EXPORTS\n")
                f.write("=" * 60 + "\n")
        except Exception as e:
            print(f"Export-Fehler: {e}")

    def zeige_ui_auswahl(self):
        self._session_beenden()
        self._aktuelle_ansicht = self.zeige_ui_auswahl
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("440x360")
            SKAL.setze_basis(440, 360)
        tk.Label(self.root, text="🌍  Willkommen · Welcome · Tervetuloa",
                 font=fnt(13, "bold"), bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(36), SKAL.s(6)))
        tk.Label(self.root, text="Version 1.0",
                 font=fnt(13, "bold"), bg=CLR["bg"], fg=CLR["text"]).pack(pady=(0, SKAL.s(6)))
        tk.Label(self.root,
                 text="Bitte wähle deine Sprache · Please choose your language\nValitse kielesi",
                 font=fnt(10), bg=CLR["bg"], fg=CLR["sub"], justify="center").pack(pady=(SKAL.s(0), SKAL.s(24)))
        for lbl, code, col in [("🇩🇪   Deutsch", "de", CLR["blue"]),
                                ("🇬🇧   English", "en", CLR["green"]),
                                ("🇫🇮   Suomi",   "fi", CLR["red"])]:
            tk.Button(self.root, text=lbl, font=fnt(13, "bold"),
                      bg=col, fg="white", relief="flat", padx=SKAL.s(0), pady=SKAL.s(12),
                      cursor="hand2", width=20,
                      command=lambda c=code: self._ui_gewaehlt(c)).pack(pady=SKAL.s(4))

    def _ui_gewaehlt(self, code):
        self.ui = code
        self.zeige_lern_auswahl()

    def zeige_lern_auswahl(self):
        self._aktuelle_ansicht = self.zeige_lern_auswahl
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("440x380")
            SKAL.setze_basis(440, 380)
        ui = self.ui
        tk.Label(self.root, text=t(ui, "lern_frage"),
                 font=fnt(14, "bold"), bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(40), SKAL.s(28)))
        for code, col in [("de", CLR["blue"]), ("en", CLR["green"]), ("fi", CLR["red"])]:
            flag = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[code]
            tk.Button(self.root, text=f"{flag}   {langname(ui, code)}",
                      font=fnt(13, "bold"), bg=col, fg="white", relief="flat",
                      padx=SKAL.s(0), pady=SKAL.s(12), cursor="hand2", width=20,
                      command=lambda c=code: self._lern_gewaehlt(c)).pack(pady=SKAL.s(4))

    def _lern_gewaehlt(self, code):
        self.ls = code
        self.zeige_hauptmenue()

    def zeige_hauptmenue(self):
        self._session_beenden()
        self._aktuelle_ansicht = self.zeige_hauptmenue
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x560")
            SKAL.setze_basis(460, 560)
        ui, ls = self.ui, self.ls

        tk.Label(self.root, text=t(ui, "titel"), font=fnt(20, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(28), SKAL.s(2)))

        flag = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ls]
        tk.Label(self.root, text=f"{flag}  {t(ui, 'lernsprache', lang=langname(ui, ls))}",
                 font=fnt(11, "bold"), bg=CLR["bg"], fg=CLR["sub"]).pack()

        vok = vokabeln_laden(ls)
        tk.Label(self.root, text=t(ui, "gespeichert", n=len(vok)),
                 font=fnt(11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(2), SKAL.s(4)))

        s   = stats_laden()
        xp  = s.get("level_xp", 0)
        lvl, xp_ak, xp_nx = xp_fortschritt(xp)
        tk.Label(self.root,
                 text=f"⭐  {t(ui,'stat_level')} {lvl}   |   {xp_ak} / {xp_nx} XP",
                 font=fnt(10, "bold"), bg=CLR["bg"], fg=CLR["xp"]).pack(pady=(SKAL.s(0), SKAL.s(4)))
        bar_frame = tk.Frame(self.root, bg=CLR["border"], height=SKAL.s(8), width=SKAL.s(300))
        bar_frame.pack(pady=(SKAL.s(0), SKAL.s(14)))
        bar_frame.pack_propagate(False)
        perc  = xp_ak / xp_nx if xp_nx else 1
        bar_w = int(300 * perc)
        if bar_w > 0:
            tk.Frame(bar_frame, bg=CLR["xp"], height=SKAL.s(8), width=bar_w).place(x=0, y=0)

        btn_cfg = {"font": ("Arial", 13, "bold"), "relief": "flat",
                   "padx": 0, "pady": 13, "cursor": "hand2", "width": 22}
        tk.Button(self.root, text=t(ui, "vok_menue_titel"), bg=CLR["blue"], fg="white",
                  command=self.zeige_vokabeln_menue, **btn_cfg).pack(pady=SKAL.s(3))
        tk.Button(self.root, text=t(ui, "statistik"),  bg="#16a085", fg="white",
                  command=self.zeige_statistik, **btn_cfg).pack(pady=SKAL.s(3))
        tk.Button(self.root, text=t(ui, "saetze"),      bg="#d35400", fg="white",
                  command=self.zeige_saetze_menue, **btn_cfg).pack(pady=SKAL.s(3))
        tk.Button(self.root, text=t(ui, "freischaltungen"), bg="#8e44ad", fg="white",
                  command=self.zeige_freischaltungen, **btn_cfg).pack(pady=SKAL.s(3))
        tk.Button(self.root, text=t(ui, "sprache_aendern"),
                  font=fnt(11, "bold"), bg=CLR["bg"], fg=CLR["text"], relief="flat",
                  cursor="hand2", command=self.zeige_ui_auswahl).pack(pady=(SKAL.s(10), SKAL.s(0)))

    def zeige_richtung(self, modus):
        ui, ls = self.ui, self.ls
        if not vokabeln_laden(ls):
            messagebox.showinfo(t(ui, "keine_titel"), t(ui, "keine_vok"))
            return
        self._aktuelle_ansicht = lambda: self.zeige_richtung(modus)
        self.clear()

        s   = stats_laden()
        xp  = s.get("level_xp", 0)
        lvl = berechne_level(xp)
        hat_gemischt = hat_freischaltung("gemischt")
        hat_blitz    = hat_freischaltung("blitz_modus") and modus == "test"
        hat_mc       = hat_freischaltung("mehrfach_wahl") and modus == "test"
        hoehe = 460
        if hat_gemischt: hoehe += 60
        if hat_blitz:    hoehe += 60
        if hat_mc:       hoehe += 60
        if self.root.winfo_width() <= 1:
            self.root.geometry(f"460x{hoehe}")
            SKAL.setze_basis(460, hoehe)

        mutter  = muttersprache_label(ui)
        lsname  = langname(ui, ls)
        flag_ls = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ls]
        flag_ui = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ui]

        header = t(ui, "lernen") if modus == "lernen" else t(ui, "test")
        tk.Label(self.root, text=header, font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(28), SKAL.s(4)))
        tk.Label(self.root, text=t(ui, "richtung_titel"),
                 font=fnt(11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(0), SKAL.s(14)))

        def karte(zeile1, zeile2, col, cb):
            f = tk.Frame(self.root, bg=CLR["white"],
                         highlightbackground=col, highlightthickness=2, cursor="hand2")
            f.pack(padx=SKAL.s(40), fill="x", pady=SKAL.s(6))
            inner = tk.Frame(f, bg=CLR["white"])
            inner.pack(padx=SKAL.s(16), pady=SKAL.s(13))
            l1 = tk.Label(inner, text=zeile1, font=fnt(13, "bold"),
                          bg=CLR["white"], fg=CLR["text"])
            l1.pack()
            l2 = tk.Label(inner, text=zeile2, font=fnt(10),
                          bg=CLR["white"], fg=CLR["sub"])
            l2.pack()
            for w in [f, inner, l1, l2]:
                w.bind("<Button-1>", lambda e: cb())

        karte(f"{flag_ui} {mutter}   →   {flag_ls} {lsname}",
              t(ui, "richtung_normal_kurz"), CLR["green"],
              lambda: self._start(modus, False))
        karte(f"{flag_ls} {lsname}   →   {flag_ui} {mutter}",
              t(ui, "richtung_umgekehrt_kurz"), CLR["orange"],
              lambda: self._start(modus, True))

        if hat_gemischt:
            karte(f"{flag_ui} ↔ {flag_ls}  Zufällig gemischt",
                  t(ui, "richtung_gemischt_kurz"), CLR["blue"],
                  lambda: self._start(modus, "gemischt"))

        karte(f"{flag_ui} ⇄ {flag_ls}  Mix: Richtung wechselt",
              t(ui, "mix_kurz"), "#1abc9c",
              lambda: self._start(modus, "mix"))

        if hat_blitz:
            karte("⚡ Blitz: 5 Sekunden pro Wort",
                  t(ui, "blitz_titel"), "#c0392b",
                  lambda: self._start("blitz", False))

        if hat_mc:
            karte("🎯 Multiple Choice",
                  t(ui, "mc_titel"), "#2980b9",
                  lambda: self._start("mc", False))

        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(20), pady=SKAL.s(10),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(pady=(SKAL.s(10), SKAL.s(6)))

    def _start(self, modus, umgekehrt):
        if modus == "lernen":
            self.zeige_lernen(umgekehrt)
        elif modus == "blitz":
            self.zeige_lvl_auswahl(False, modus="blitz")
        elif modus == "mc":
            self.zeige_lvl_auswahl(False, modus="mc")
        elif umgekehrt == "mix":
            self.zeige_lvl_auswahl("mix")
        else:
            self.zeige_lvl_auswahl(umgekehrt)

    def zeige_lvl_auswahl(self, umgekehrt, modus="test"):
        ui, ls = self.ui, self.ls
        vok    = vokabeln_laden(ls)
        self._aktuelle_ansicht = lambda: self.zeige_lvl_auswahl(umgekehrt, modus=modus)
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x360")
            SKAL.setze_basis(460, 360)

        tk.Label(self.root, text=t(ui, "lvl_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(28), SKAL.s(4)))
        tk.Label(self.root, text=t(ui, "lvl_hint"),
                 font=fnt(10), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(0), SKAL.s(16)))

        rf = make_frame(self.root)
        rf.pack()
        tk.Label(rf, text=t(ui, "lvl_prozent"), font=fnt(11, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(side="left", padx=(SKAL.s(0), SKAL.s(8)))
        proz_var   = tk.StringVar(value="100")
        proz_entry = tk.Entry(rf, textvariable=proz_var, font=fnt(14, "bold"),
                              width=5, justify="center",
                              fg=CLR["entry_fg"], bg=CLR["entry_bg"],
                              insertbackground=CLR["entry_ins"],
                              bd=1, relief="solid")
        proz_entry.pack(side="left")

        tk.Label(self.root, text=f"(max. {len(vok)} Wörter)",
                 font=fnt(10), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(4), SKAL.s(16)))

        modus_var = tk.StringVar(value="schwach")
        for txt, val, col in [(t(ui, "lvl_schwach"), "schwach", CLR["orange"]),
                               (t(ui, "lvl_zufall"),  "zufall",  CLR["blue"])]:
            tk.Radiobutton(self.root, text=txt, variable=modus_var, value=val,
                           font=fnt(11), bg=CLR["bg"], fg=col,
                           activebackground=CLR["bg"], selectcolor=CLR["bg"],
                           cursor="hand2").pack(anchor="w", padx=SKAL.s(60))

        err_lbl = tk.Label(self.root, text="", font=fnt(10),
                           bg=CLR["bg"], fg=CLR["red"])
        err_lbl.pack(pady=(SKAL.s(8), SKAL.s(0)))

        def starten():
            try:
                p = int(proz_var.get().strip())
                assert 1 <= p <= 100
            except Exception:
                err_lbl.config(text=t(ui, "lvl_fehler"))
                return
            n      = max(1, math.ceil(len(vok) * p / 100))
            auswahl = self._wort_auswahl(vok, n, modus_var.get())
            if modus == "blitz":
                self.zeige_blitz(False, auswahl=auswahl)
            elif modus == "mc":
                self.zeige_mc(auswahl=auswahl)
            else:
                self.zeige_test(umgekehrt, auswahl=auswahl)

        row = make_frame(self.root)
        row.pack(pady=SKAL.s(14))
        tk.Button(row, text=t(ui, "lvl_start"), font=fnt(12, "bold"),
                  bg=CLR["orange"], fg="white", relief="flat", padx=SKAL.s(20), pady=SKAL.s(8),
                  cursor="hand2", command=starten).pack(side="left", padx=SKAL.s(6))
        tk.Button(row, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(side="left", padx=SKAL.s(6))

        self.root.bind("<Return>", lambda e: starten())
        proz_entry.focus()

    def _wort_auswahl(self, vok, n, modus):
        s  = stats_laden()
        ws = s.get("wort_stats", {})

        def fehler_score(v):
            key   = v.get("nativ", "")
            st    = ws.get(key, {})
            r, f  = st.get("richtig", 0), st.get("falsch", 0)
            total = r + f
            return 0.5 if total == 0 else f / total

        if modus == "schwach":
            return sorted(vok, key=fehler_score, reverse=True)[:n]
        else:
            sample = vok[:]
            random.shuffle(sample)
            return sample[:n]

    def zeige_vokabeln_menue(self):
        self._aktuelle_ansicht = self.zeige_vokabeln_menue
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x420")
            SKAL.setze_basis(460, 420)
        ui, ls = self.ui, self.ls

        tk.Label(self.root, text=t(ui, "vok_menue_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(28), SKAL.s(4)))

        vok = vokabeln_laden(ls)
        tk.Label(self.root, text=t(ui, "gespeichert", n=len(vok)),
                 font=fnt(11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(0), SKAL.s(20)))

        btn_cfg = {"font": ("Arial", 13, "bold"), "relief": "flat",
                   "padx": 0, "pady": 13, "cursor": "hand2", "width": 22}
        tk.Button(self.root, text=t(ui, "eintragen"), bg=CLR["blue"], fg="white",
                  command=self.zeige_eintragen, **btn_cfg).pack(pady=SKAL.s(4))
        tk.Button(self.root, text=t(ui, "lernen"), bg=CLR["green"], fg="white",
                  command=lambda: self.zeige_richtung("lernen"), **btn_cfg).pack(pady=SKAL.s(4))
        tk.Button(self.root, text=t(ui, "test"), bg=CLR["orange"], fg="white",
                  command=lambda: self.zeige_richtung("test"), **btn_cfg).pack(pady=SKAL.s(4))
        tk.Button(self.root, text=t(ui, "bearbeiten"), bg=CLR["purple"], fg="white",
                  command=self.zeige_bearbeiten, **btn_cfg).pack(pady=SKAL.s(4))
        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(pady=(SKAL.s(16), SKAL.s(0)))

    def zeige_eintragen(self):
        self._aktuelle_ansicht = self.zeige_eintragen
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x560")
            SKAL.setze_basis(460, 560)
        ui, ls = self.ui, self.ls
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)

        tk.Label(self.root, text=t(ui, "ein_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(22), SKAL.s(2)))
        tk.Label(self.root, text=t(ui, "ein_hinweis"),
                 font=fnt(10), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(0), SKAL.s(14)))

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(0), SKAL.s(10)))
        tk.Label(f_a, text=mutter.upper(), font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(SKAL.s(8), SKAL.s(2)))
        self.ein_a = tk.Entry(f_a, font=fnt(20, "bold"), justify="center",
                              fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                              bg=CLR["entry_bg"], insertbackground=CLR["entry_ins"])
        self.ein_a.pack(fill="x", padx=SKAL.s(12), pady=(SKAL.s(0), SKAL.s(10)))

        f_b = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_b.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(0), SKAL.s(10)))
        tk.Label(f_b, text=nativname(ls).upper(), font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(SKAL.s(8), SKAL.s(2)))
        self.ein_b = tk.Entry(f_b, font=fnt(20, "bold"), justify="center",
                              fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                              bg=CLR["entry_bg"], insertbackground=CLR["entry_ins"])
        self.ein_b.pack(fill="x", padx=SKAL.s(12), pady=(SKAL.s(0), SKAL.s(10)))

        f_audio = tk.Frame(self.root, bg=CLR["white"],
                           highlightbackground=CLR["card_border"], highlightthickness=2)
        f_audio.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(0), SKAL.s(10)))
        tk.Label(f_audio, text="🎵  AUDIO (optional)", font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(SKAL.s(8), SKAL.s(2)))
        self.ein_audio_var = tk.StringVar(value="")
        af_row = tk.Frame(f_audio, bg=CLR["white"])
        af_row.pack(fill="x", padx=SKAL.s(12), pady=(SKAL.s(0), SKAL.s(10)))
        self.ein_audio_lbl = tk.Label(af_row, text="(keine)",
                                      font=fnt(10), bg=CLR["white"],
                                      fg=CLR["sub"], anchor="w")
        self.ein_audio_lbl.pack(side="left", fill="x", expand=True)

        def waehle_ein_audio():
            pfad = filedialog.askopenfilename(
                title="MP3-Datei wählen",
                initialdir=AUDIO_DIR,
                filetypes=[("MP3-Dateien", "*.mp3"), ("Alle Dateien", "*.*")])
            if pfad:
                name = os.path.basename(pfad)
                self.ein_audio_var.set(name)
                self.ein_audio_lbl.config(text=name, fg=CLR["green"])

        def audio_loeschen():
            self.ein_audio_var.set("")
            self.ein_audio_lbl.config(text="(keine)", fg=CLR["sub"])

        tk.Button(af_row, text="📂 Wählen", font=fnt(10),
                  bg=CLR["blue"], fg="white", relief="flat", padx=SKAL.s(8), pady=SKAL.s(3),
                  cursor="hand2", command=waehle_ein_audio).pack(side="left", padx=(SKAL.s(6), SKAL.s(2)))
        tk.Button(af_row, text="✕", font=fnt(10),
                  bg=CLR["red"], fg="white", relief="flat", padx=SKAL.s(6), pady=SKAL.s(3),
                  cursor="hand2", command=audio_loeschen).pack(side="left", padx=(SKAL.s(2), SKAL.s(0)))

        self.lbl_ein_status = tk.Label(self.root, text="", font=fnt(11),
                                       bg=CLR["bg"], fg="#27ae60")
        self.lbl_ein_status.pack(pady=(SKAL.s(0), SKAL.s(10)))

        row = make_frame(self.root)
        row.pack()
        tk.Button(row, text=t(ui, "speichern"), font=fnt(12, "bold"),
                  bg=CLR["blue"], fg="white", relief="flat", padx=SKAL.s(18), pady=SKAL.s(8),
                  cursor="hand2", command=self.eintragen_speichern).pack(side="left", padx=SKAL.s(6))
        tk.Button(row, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(side="left", padx=SKAL.s(6))

        self.root.bind("<Return>", lambda e: self.eintragen_speichern())
        self.ein_a.focus()

    def eintragen_speichern(self):
        ui, ls = self.ui, self.ls
        a = self.ein_a.get().strip()
        b = self.ein_b.get().strip()
        if not a or not b:
            self.lbl_ein_status.config(text=t(ui, "ein_fehler"), fg=CLR["red"])
            return
        audio = self.ein_audio_var.get().strip() if hasattr(self, 'ein_audio_var') else ""
        if not audio:
            auto_name = gtts_dateiname(b, ls)
            self.lbl_ein_status.config(text="🎵 Audio wird geladen …", fg=CLR["sub"])
            self.root.update_idletasks()
            if gtts_herunterladen(b, ls, auto_name):
                audio = auto_name
        liste = vokabeln_laden(ls)
        liste.append({"nativ": a, "lern": b, "audio": audio})
        vokabeln_speichern(ls, liste)
        self.lbl_ein_status.config(text=t(ui, "ein_ok", w=a), fg="#27ae60")
        self.ein_a.delete(0, tk.END)
        self.ein_b.delete(0, tk.END)
        self.ein_audio_var.set("")
        self.ein_audio_lbl.config(text="(keine)", fg=CLR["sub"])
        self.ein_a.focus()

    def zeige_lernen(self, umgekehrt=False):
        self._session_starten()
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)
        lsname = langname(ui, ls)
        self._aktuelle_ansicht = lambda: self.zeige_lernen(umgekehrt)
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x450")
            SKAL.setze_basis(460, 450)

        self.lern_liste      = vokabeln_laden(ls)[:]
        random.shuffle(self.lern_liste)
        self.lern_index      = 0
        self.lern_aufgedeckt = False
        self.lern_umgekehrt  = umgekehrt

        if umgekehrt == "gemischt":
            self.lern_key_oben  = None
            self.lern_key_unten = None
        elif umgekehrt:
            self.lern_key_oben, self.lern_key_unten = "lern", "nativ"
        else:
            self.lern_key_oben, self.lern_key_unten = "nativ", "lern"

        titel_key = "lern_titel_r" if umgekehrt is True else "lern_titel"
        tk.Label(self.root, text=t(ui, titel_key), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(20), SKAL.s(2)))
        tk.Label(self.root, text=t(ui, "lern_hinweis"),
                 font=fnt(10), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(0), SKAL.s(10)))

        self.lbl_lern_nr = tk.Label(self.root, text="", font=fnt(11),
                                    bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_lern_nr.pack()

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(2), SKAL.s(8)))
        self.lbl_lern_a = tk.Label(f_a, text="", font=fnt(24, "bold"),
                                   bg=CLR["white"], fg=CLR["text"])
        self.lbl_lern_a.pack(pady=(SKAL.s(6), SKAL.s(12)))

        self.f_b_lern = tk.Frame(self.root, bg=CLR["light"],
                                 highlightbackground=CLR["card_border"], highlightthickness=2,
                                 cursor="hand2")
        self.f_b_lern.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(0), SKAL.s(14)))
        self.lbl_lern_b = tk.Label(self.f_b_lern, text=t(ui, "lern_versteckt"),
                                   font=fnt(15), bg=CLR["light"], fg=CLR["sub"])
        self.lbl_lern_b.pack(pady=(SKAL.s(8), SKAL.s(12)))
        for w in [self.f_b_lern, self.lbl_lern_b]:
            w.bind("<Button-1>", lambda e: self.lern_toggle())

        row = make_frame(self.root)
        row.pack()
        self.btn_lern_vorherige = tk.Button(row, text=t(ui, "lern_vorherige"), font=fnt(11),
                  bg=CLR["orange"], fg="white", relief="flat", padx=SKAL.s(12), pady=SKAL.s(8),
                  cursor="hand2", command=self.lern_zurueck_wort)
        self.btn_lern_vorherige.pack(side="left", padx=SKAL.s(6))
        tk.Button(row, text=t(ui, "lern_play"), font=fnt(11, "bold"),
                  bg="#16a085", fg="white", relief="flat", padx=SKAL.s(12), pady=SKAL.s(8),
                  cursor="hand2", command=self._lern_play_audio).pack(side="left", padx=SKAL.s(6))
        tk.Button(row, text=t(ui, "weiter"), font=fnt(12, "bold"),
                  bg=CLR["green"], fg="white", relief="flat", padx=SKAL.s(20), pady=SKAL.s(8),
                  cursor="hand2", command=self.lern_weiter).pack(side="left", padx=SKAL.s(6))
        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(20), pady=SKAL.s(10),
                  cursor="hand2", command=self._lern_zurueck).pack(pady=(SKAL.s(8), SKAL.s(4)))

        self.root.bind("<h>", lambda e: self.lern_toggle())
        self.root.bind("<H>", lambda e: self.lern_toggle())
        self.lern_zeige()

    def _lern_zurueck(self):
        self._session_beenden()
        self.zeige_hauptmenue()

    def _lern_play_audio(self):
        ui = self.ui
        if not PYGAME_OK:
            messagebox.showinfo("Audio", "pygame nicht installiert.\npip install pygame")
            return
        if self.lern_index >= len(self.lern_liste):
            return
        vok       = self.lern_liste[self.lern_index]
        dateiname = vok.get("audio", "")
        pfad      = audio_pfad(dateiname)
        if pfad and os.path.exists(pfad):
            try:
                pygame.mixer.music.load(pfad)
                pygame.mixer.music.play()
            except Exception as e:
                messagebox.showerror("Audio", str(e))
        else:
            messagebox.showinfo("Audio", t(ui, "test_kein_audio", folder=AUDIO_DIR))

    def lern_zeige(self):
        ui = self.ui
        if self.lern_index >= len(self.lern_liste):
            self._session_beenden()
            messagebox.showinfo("🎉", t(ui, "lern_fertig", n=len(self.lern_liste)))
            self.zeige_hauptmenue()
            return
        vok = self.lern_liste[self.lern_index]
        self.lbl_lern_nr.config(
            text=t(ui, "lern_karte", i=self.lern_index+1, n=len(self.lern_liste)))

        if self.lern_umgekehrt == "gemischt":
            self.lern_key_oben  = random.choice(["nativ", "lern"])
            self.lern_key_unten = "lern" if self.lern_key_oben == "nativ" else "nativ"

        self.lbl_lern_a.config(text=vok[self.lern_key_oben])
        self.lern_aufgedeckt = False
        self.lbl_lern_b.config(text=t(ui, "lern_versteckt"), fg=CLR["sub"], font=fnt(15))
        self.f_b_lern.config(bg=CLR["light"])
        self.lbl_lern_b.config(bg=CLR["light"])
        if hasattr(self, "btn_lern_vorherige"):
            state = "disabled" if self.lern_index == 0 else "normal"
            self.btn_lern_vorherige.config(state=state)

    def lern_toggle(self):
        if self.lern_index >= len(self.lern_liste):
            return
        vok = self.lern_liste[self.lern_index]
        if not self.lern_aufgedeckt:
            self.lbl_lern_b.config(text=vok[self.lern_key_unten],
                                   fg=CLR["text"], font=fnt(24, "bold"))
            self.f_b_lern.config(bg=CLR["white"])
            self.lbl_lern_b.config(bg=CLR["white"])
            self.lern_aufgedeckt = True
        else:
            ui = self.ui
            self.lbl_lern_b.config(text=t(ui, "lern_versteckt"), fg=CLR["sub"], font=fnt(15))
            self.f_b_lern.config(bg=CLR["light"])
            self.lbl_lern_b.config(bg=CLR["light"])
            self.lern_aufgedeckt = False

    def lern_weiter(self):
        self.lern_index += 1
        self.lern_zeige()

    def lern_zurueck_wort(self):
        if self.lern_index > 0:
            self.lern_index -= 1
            self.lern_zeige()

    def zeige_test(self, umgekehrt=False, auswahl=None):
        self._session_starten()
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)
        lsname = langname(ui, ls)

        self._aktuelle_ansicht = lambda: self.zeige_test(umgekehrt, auswahl=auswahl)
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x530")
            SKAL.setze_basis(460, 530)

        vok_liste            = auswahl if auswahl is not None else vokabeln_laden(ls)
        self.test_liste      = vok_liste[:]
        random.shuffle(self.test_liste)
        self.test_index      = 0
        self.test_versuche_z = 0
        self.test_richtig_n  = 0
        self.test_falsch_n   = 0
        self.test_umgekehrt  = umgekehrt
        self.test_mix_zaehler  = 0
        self.test_streak     = 0
        self.joker_verfuegbar = hat_freischaltung("joker")
        self.joker_genutzt_runde = False
        self.streak_bonus_aktiv  = hat_freischaltung("streak_bonus")
        self.xp_multiplikator    = 1.5 if hat_freischaltung("xp_multiplikator") else 1.0

        if umgekehrt == "gemischt":
            self.test_key_oben    = None
            self.test_key_loesung = None
        elif umgekehrt:
            self.test_key_oben    = "lern"
            self.test_key_loesung = "nativ"
        else:
            self.test_key_oben    = "nativ"
            self.test_key_loesung = "lern"

        if umgekehrt == "gemischt":
            titel_key = "test_titel_g"
        elif umgekehrt:
            titel_key = "test_titel_r"
        else:
            titel_key = "test_titel"

        tk.Label(self.root, text=t(ui, titel_key), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(SKAL.s(16), SKAL.s(2)))

        self.lbl_test_nr   = tk.Label(self.root, text="", font=fnt(11),
                                      bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_test_nr.pack()
        self.lbl_test_vers = tk.Label(self.root, text="", font=fnt(11),
                                      bg=CLR["bg"], fg=CLR["orange"])
        self.lbl_test_vers.pack(pady=(SKAL.s(2), SKAL.s(0)))

        self.lbl_streak = tk.Label(self.root, text="", font=fnt(11, "bold"),
                                   bg=CLR["bg"], fg="#e74c3c")
        self.lbl_streak.pack()

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(8), SKAL.s(6)))
        self.lbl_test_label_oben = tk.Label(f_a, text="", font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"])
        self.lbl_test_label_oben.pack(pady=(SKAL.s(8), SKAL.s(2)))
        self.lbl_test_a = tk.Label(f_a, text="", font=fnt(22, "bold"),
                                   bg=CLR["white"], fg=CLR["text"])
        self.lbl_test_a.pack(pady=(SKAL.s(0), SKAL.s(10)))

        f_b = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_b.pack(padx=SKAL.s(40), fill="x", pady=(SKAL.s(0), SKAL.s(6)))
        self.lbl_test_label_eingabe = tk.Label(f_b, text="", font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"])
        self.lbl_test_label_eingabe.pack(pady=(SKAL.s(8), SKAL.s(2)))
        self.test_eingabe = tk.Entry(f_b, font=fnt(20, "bold"), justify="center",
                                     fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                                     bg=CLR["entry_bg"], insertbackground=CLR["entry_ins"])
        self.test_eingabe.pack(fill="x", padx=SKAL.s(12), pady=(SKAL.s(0), SKAL.s(8)))

        if umgekehrt == "gemischt":
            self.lbl_test_label_oben.config(text="?")
            self.lbl_test_label_eingabe.config(text="?")
        elif umgekehrt:
            self.lbl_test_label_oben.config(text=nativname(ls).upper())
            self.lbl_test_label_eingabe.config(text=mutter.upper())
        else:
            self.lbl_test_label_oben.config(text=mutter.upper())
            self.lbl_test_label_eingabe.config(text=nativname(ls).upper())

        # Sonderzeichen-Zeile – wird pro Wort ein/ausgeblendet
        self.sz_row = make_frame(self.root)
        self.sz_row.pack(pady=(SKAL.s(0), SKAL.s(4)))
        self.sz_buttons = []
        for zeichen in ["ß", "Ü", "Ä", "Ö"]:
            b = tk.Button(self.sz_row, text=zeichen, font=fnt(15, "bold"),
                          bg=CLR["blue"], fg="white", relief="flat",
                          padx=SKAL.s(18), pady=SKAL.s(6), cursor="hand2",
                          command=lambda z=zeichen: self._sonderzeichen(z))
            b.pack(side="left", padx=SKAL.s(6))
            self.sz_buttons.append(b)

        self.lbl_test_feedback = tk.Label(self.root, text="", font=fnt(12),
                                          bg=CLR["bg"])
        self.lbl_test_feedback.pack(pady=(SKAL.s(0), SKAL.s(4)))

        row = make_frame(self.root)
        row.pack()
        self.btn_play = tk.Button(row, text=t(ui, "test_play"),
                                  font=fnt(11, "bold"),
                                  bg="#16a085", fg="white", relief="flat",
                                  padx=SKAL.s(12), pady=SKAL.s(8), cursor="hand2",
                                  command=self._test_play_audio)
        self.btn_play.pack(side="left", padx=SKAL.s(4))
        self.btn_pruefen = tk.Button(row, text=t(ui, "test_prufen"),
                                     font=fnt(12, "bold"),
                                     bg=CLR["orange"], fg="white", relief="flat",
                                     padx=SKAL.s(20), pady=SKAL.s(8), cursor="hand2",
                                     command=self.test_pruefen)
        self.btn_pruefen.pack(side="left", padx=SKAL.s(4))
        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(20), pady=SKAL.s(10),
                  cursor="hand2", command=self._test_zurueck).pack(pady=(SKAL.s(6), SKAL.s(4)))

        if self.joker_verfuegbar:
            self.btn_joker = tk.Button(self.root, text=t(ui, "joker_btn"),
                                       font=fnt(10, "bold"),
                                       bg="#8e44ad", fg="white", relief="flat",
                                       padx=SKAL.s(12), pady=SKAL.s(5), cursor="hand2",
                                       command=self._joker_nutzen)
            self.btn_joker.pack(pady=(SKAL.s(4), SKAL.s(0)))

        self.root.bind("<Return>", lambda e: self.test_pruefen())
        self.test_naechste()

    def _joker_nutzen(self):
        if self.joker_genutzt_runde:
            return
        self.joker_genutzt_runde = True
        ui = self.ui
        self.btn_joker.config(text=t(ui, "joker_genutzt"), bg="#7f8c8d", state="disabled")
        self._joker_aktiv = True

    def _sonderzeichen(self, z):
        try:
            pos = self.test_eingabe.index(tk.INSERT)
            self.test_eingabe.insert(pos, z)
        except Exception:
            self.test_eingabe.insert(tk.END, z)
        self.test_eingabe.focus()

    def _test_play_audio(self):
        ui = self.ui
        if not PYGAME_OK:
            messagebox.showinfo("Audio", "pygame nicht installiert.\npip install pygame")
            return
        if self.test_index >= len(self.test_liste):
            return
        vok       = self.test_liste[self.test_index]
        dateiname = vok.get("audio", "")
        pfad      = audio_pfad(dateiname)
        if pfad and os.path.exists(pfad):
            try:
                pygame.mixer.music.load(pfad)
                pygame.mixer.music.play()
            except Exception as e:
                messagebox.showerror("Audio", str(e))
        else:
            messagebox.showinfo("Audio", t(ui, "test_kein_audio", folder=AUDIO_DIR))

    def _test_zurueck(self):
        self._session_beenden()
        self.zeige_hauptmenue()

    def test_naechste(self):
        ui = self.ui
        if self.test_index >= len(self.test_liste):
            self._test_abschluss()
            return
        self.test_versuche_z = 0
        self._joker_aktiv = False
        vok = self.test_liste[self.test_index]

        if self.test_umgekehrt == "gemischt":
            key_oben = random.choice(["nativ", "lern"])
            self.test_key_oben    = key_oben
            self.test_key_loesung = "lern" if key_oben == "nativ" else "nativ"
            mutter = muttersprache_label(ui)
            if key_oben == "nativ":
                self.lbl_test_label_oben.config(text=mutter.upper())
                self.lbl_test_label_eingabe.config(text=nativname(self.ls).upper())
            else:
                self.lbl_test_label_oben.config(text=nativname(self.ls).upper())
                self.lbl_test_label_eingabe.config(text=mutter.upper())

        elif self.test_umgekehrt == "mix":
            umgekehrt_jetzt = (self.test_mix_zaehler % 2 == 1)
            self.test_mix_zaehler += 1
            mutter = muttersprache_label(ui)
            if umgekehrt_jetzt:
                self.test_key_oben    = "lern"
                self.test_key_loesung = "nativ"
                self.lbl_test_label_oben.config(text=nativname(self.ls).upper())
                self.lbl_test_label_eingabe.config(text=mutter.upper())
            else:
                self.test_key_oben    = "nativ"
                self.test_key_loesung = "lern"
                self.lbl_test_label_oben.config(text=mutter.upper())
                self.lbl_test_label_eingabe.config(text=nativname(self.ls).upper())

        self.lbl_test_a.config(text=vok[self.test_key_oben])
        self.lbl_test_nr.config(
            text=t(ui, "test_frage", i=self.test_index+1, n=len(self.test_liste)))
        self.lbl_test_vers.config(text=t(ui, "test_versuche", v=3))
        self.lbl_test_feedback.config(text="")
        if self.test_streak >= 5 and self.streak_bonus_aktiv:
            self.lbl_streak.config(text=t(ui, "streak", n=self.test_streak) + " 2x XP!")
        elif self.test_streak >= 3:
            self.lbl_streak.config(text=t(ui, "streak", n=self.test_streak))
        else:
            self.lbl_streak.config(text="")
        # Sonderzeichen-Buttons: nur anzeigen wenn Deutsch eingetippt werden muss
        mutter_sprache = self.ui  # ui ist die Muttersprache
        loesung_ist_deutsch = (self.test_key_loesung == "nativ" and mutter_sprache == "de") or \
                               (self.test_key_loesung == "lern" and self.ls == "de")
        if hasattr(self, "sz_row"):
            if loesung_ist_deutsch:
                self.sz_row.pack(pady=(SKAL.s(0), SKAL.s(4)))
            else:
                self.sz_row.pack_forget()
        self.test_eingabe.config(state="normal")
        self.test_eingabe.delete(0, tk.END)
        self.btn_pruefen.config(state="normal")
        self.test_eingabe.focus()

    def test_pruefen(self):
        if self.test_eingabe.cget("state") == "disabled":
            return
        ui      = self.ui
        antwort = self.test_eingabe.get().strip().lower()
        vok     = self.test_liste[self.test_index]
        loesung = vok[self.test_key_loesung]
        wort_key = vok.get("nativ", "")

        if antwort == loesung.lower():
            self.test_richtig_n += 1
            self.test_streak += 1
            xp_gewinn = self._xp_fuer_richtig()
            self._update_wort_stats(wort_key, richtig=True, xp=xp_gewinn)
            feedback = t(ui, "test_richtig") + f"  {t(ui,'xp_gewinn', xp=xp_gewinn)}"
            self.lbl_test_feedback.config(text=feedback, fg="#27ae60")
            self.test_eingabe.config(state="disabled")
            self.btn_pruefen.config(state="disabled")
            self.root.after(900, self._test_weiter)
        else:
            self.test_versuche_z += 1
            verbleibend = 3 - self.test_versuche_z
            if self.test_versuche_z >= 3:
                self.test_falsch_n += 1
                self.test_streak = 0
                if hasattr(self, '_joker_aktiv') and self._joker_aktiv:
                    self._joker_aktiv = False
                    self._update_wort_stats(wort_key, richtig=False, xp=0)
                    self.lbl_test_feedback.config(
                        text=t(ui, "test_falsch_end") + "  " + t(ui, "joker_angewendet"),
                        fg=CLR["orange"])
                else:
                    xp_verlust = self._xp_verlust()
                    self._update_wort_stats(wort_key, richtig=False, xp=xp_verlust)
                    self.lbl_test_feedback.config(
                        text=t(ui, "test_falsch_end") + f"  {t(ui,'xp_verlust', xp=xp_verlust)}",
                        fg=CLR["red"])
                self.test_eingabe.config(state="disabled")
                self.btn_pruefen.config(state="disabled")
                self.test_popup(loesung)
            else:
                e_suf = "e" if verbleibend > 1 else ""
                self.lbl_test_feedback.config(
                    text=t(ui, "test_falsch_n", v=verbleibend, e=e_suf), fg=CLR["red"])
                self.lbl_test_vers.config(text=t(ui, "test_versuche", v=verbleibend))
                self.test_eingabe.delete(0, tk.END)
                self.test_eingabe.focus()

    def _xp_fuer_richtig(self):
        basis = 10
        if self.test_streak >= 5 and self.streak_bonus_aktiv:
            basis = int(basis * 2)
        return int(basis * self.xp_multiplikator)

    def _xp_verlust(self):
        basis = self._xp_fuer_richtig()
        verlust = max(1, basis // 2)
        return verlust

    def _update_wort_stats(self, key, richtig, xp=10):
        s  = stats_laden()
        ws = s.setdefault("wort_stats", {})
        ws.setdefault(key, {"richtig": 0, "falsch": 0})
        if richtig:
            ws[key]["richtig"] += 1
            s["richtig"]   = s.get("richtig", 0) + 1
            s["level_xp"]  = s.get("level_xp", 0) + xp
        else:
            ws[key]["falsch"] += 1
            s["falsch"] = s.get("falsch", 0) + 1
            if xp > 0:
                s["level_xp"] = max(0, s.get("level_xp", 0) - xp)
                lvl_neu = berechne_level(s["level_xp"])
                frei    = get_freigeschaltet(s)
                min_lvl = 1
                for (req, k, _, _) in FREISCHALTUNGEN["de"]:
                    if k in frei:
                        min_lvl = max(min_lvl, req)
                if lvl_neu < min_lvl:
                    s["level_xp"] = xp_fuer_level(min_lvl)

        if "freigeschaltet" not in s:
            s["freigeschaltet"] = []
        neu = check_neue_freischaltungen(s, ui=self.ui)
        stats_speichern(s)

        if neu and richtig:
            self.root.after(1200, lambda: self._zeige_freischaltung_popup(neu, s))

    def _zeige_freischaltung_popup(self, neu_liste, s):
        ui = self.ui
        lvl = berechne_level(s.get("level_xp", 0))
        popup = tk.Toplevel(self.root)
        popup.title("🎉 Level Up!")
        popup.resizable(False, False)
        popup.configure(bg=CLR["popup_bg"])
        popup.grab_set()

        tk.Label(popup, text=t(ui, "level_auf", lvl=lvl),
                 font=fnt(14, "bold"), bg=CLR["popup_bg"], fg=CLR["xp"]).pack(pady=(SKAL.s(20), SKAL.s(8)), padx=SKAL.s(30))

        for (key, beschr, icon, req_lvl) in neu_liste:
            tk.Label(popup, text=f"{icon}  {beschr}",
                     font=fnt(12), bg=CLR["popup_bg"], fg=CLR["text"]).pack(pady=SKAL.s(4), padx=SKAL.s(30))

        tk.Label(popup,
                 text="👉 Aktiviere es unter 'Freischaltungen'!",
                 font=fnt(10, "italic"), bg=CLR["popup_bg"], fg=CLR["sub"]).pack(pady=(SKAL.s(4), SKAL.s(0)), padx=SKAL.s(30))

        tk.Button(popup, text="OK  🎉", font=fnt(12, "bold"),
                  bg=CLR["xp"], fg="white", relief="flat", padx=SKAL.s(20), pady=SKAL.s(8),
                  cursor="hand2", command=popup.destroy).pack(pady=(SKAL.s(12), SKAL.s(20)))

        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 180
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 120
        popup.geometry(f"360x{100 + len(neu_liste)*44}+{x}+{y}")

    def _test_weiter(self):
        self.test_index += 1
        self.test_naechste()

    def _test_abschluss(self):
        self._session_beenden()
        ui = self.ui
        g  = len(self.test_liste)
        r  = self.test_richtig_n
        f  = self.test_falsch_n
        p  = int((r / g) * 100) if g else 0
        s  = stats_laden()
        lvl = berechne_level(s.get("level_xp", 0))
        messagebox.showinfo("🎉",
            t(ui, "test_ergebnis", r=r, g=g, p=p, f=f) +
            f"\n\n{t(ui,'stat_level')} {lvl}")
        self.zeige_hauptmenue()

    def test_popup(self, loesung):
        ui = self.ui
        popup = tk.Toplevel(self.root)
        popup.title(t(ui, "test_3x"))
        popup.resizable(False, False)
        popup.configure(bg=CLR["popup_bg"])
        popup.grab_set()
        tk.Label(popup, text=t(ui, "test_3x"), font=fnt(14, "bold"),
                 bg=CLR["popup_bg"], fg=CLR["red"]).pack(pady=(SKAL.s(26), SKAL.s(6)), padx=SKAL.s(30))
        tk.Label(popup, text=t(ui, "test_loesung"), font=fnt(11),
                 bg=CLR["popup_bg"], fg=CLR["sub"]).pack()
        tk.Label(popup, text=loesung, font=fnt(28, "bold"),
                 bg=CLR["popup_bg"], fg=CLR["text"]).pack(pady=(SKAL.s(6), SKAL.s(20)), padx=SKAL.s(40))

        def weiter():
            popup.destroy()
            self.test_index += 1
            self.test_naechste()

        tk.Button(popup, text=t(ui, "weiter"), font=fnt(12, "bold"),
                  bg=CLR["orange"], fg="white", relief="flat",
                  padx=SKAL.s(24), pady=SKAL.s(8), cursor="hand2", command=weiter).pack(pady=(SKAL.s(0), SKAL.s(22)))
        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 160
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 110
        popup.geometry(f"320x220+{x}+{y}")

    def zeige_blitz(self, umgekehrt=False, auswahl=None):
        self._session_starten()
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)

        self._aktuelle_ansicht = lambda: self.zeige_blitz(umgekehrt, auswahl=auswahl)
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x480")
            SKAL.setze_basis(460, 480)
        self._blitz_after = None

        vok_liste = auswahl if auswahl is not None else vokabeln_laden(ls)
        self.test_liste      = vok_liste[:]
        random.shuffle(self.test_liste)
        self.test_index      = 0
        self.test_richtig_n  = 0
        self.test_falsch_n   = 0
        self.test_umgekehrt  = umgekehrt
        self.test_key_oben    = "nativ"
        self.test_key_loesung = "lern"
        self.test_streak     = 0
        self.xp_multiplikator = 1.5 if hat_freischaltung("xp_multiplikator") else 1.0
        self.streak_bonus_aktiv = hat_freischaltung("streak_bonus")
        self.joker_verfuegbar   = False
        self._blitz_zeit_rest   = 5

        tk.Label(self.root, text=t(ui, "blitz_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["red"]).pack(pady=(16, 2))

        self.lbl_test_nr = tk.Label(self.root, text="", font=fnt(11),
                                    bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_test_nr.pack()

        self.lbl_blitz_timer = tk.Label(self.root, text="⏱ 5s",
                                         font=fnt(18, "bold"),
                                         bg=CLR["bg"], fg=CLR["red"])
        self.lbl_blitz_timer.pack()

        self.lbl_streak = tk.Label(self.root, text="", font=fnt(11, "bold"),
                                   bg=CLR["bg"], fg="#e74c3c")
        self.lbl_streak.pack()

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=SKAL.s(40), fill="x", pady=(8, 6))
        tk.Label(f_a, text=mutter.upper(), font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.lbl_test_a = tk.Label(f_a, text="", font=fnt(22, "bold"),
                                   bg=CLR["white"], fg=CLR["text"])
        self.lbl_test_a.pack(pady=(0, 10))

        f_b = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_b.pack(padx=SKAL.s(40), fill="x", pady=(0, 6))
        tk.Label(f_b, text=nativname(ls).upper(), font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.test_eingabe = tk.Entry(f_b, font=fnt(20, "bold"), justify="center",
                                     fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                                     bg=CLR["entry_bg"], insertbackground=CLR["entry_ins"])
        self.test_eingabe.pack(fill="x", padx=SKAL.s(12), pady=(0, 8))

        self.lbl_test_feedback = tk.Label(self.root, text="", font=fnt(12),
                                          bg=CLR["bg"])
        self.lbl_test_feedback.pack(pady=(0, 4))

        row = make_frame(self.root)
        row.pack()
        self.btn_pruefen = tk.Button(row, text=t(ui, "test_prufen"),
                                     font=fnt(12, "bold"),
                                     bg=CLR["red"], fg="white", relief="flat",
                                     padx=SKAL.s(20), pady=SKAL.s(8), cursor="hand2",
                                     command=self._blitz_pruefen)
        self.btn_pruefen.pack(side="left", padx=SKAL.s(4))
        tk.Button(row, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self._test_zurueck).pack(side="left", padx=SKAL.s(4))

        self.root.bind("<Return>", lambda e: self._blitz_pruefen())
        self._blitz_naechste()

    def _blitz_naechste(self):
        ui = self.ui
        if self.test_index >= len(self.test_liste):
            self._test_abschluss()
            return
        vok = self.test_liste[self.test_index]
        self.lbl_test_a.config(text=vok[self.test_key_oben])
        self.lbl_test_nr.config(
            text=t(ui, "test_frage", i=self.test_index+1, n=len(self.test_liste)))
        self.lbl_test_feedback.config(text="")
        self.test_eingabe.config(state="normal")
        self.test_eingabe.delete(0, tk.END)
        self.btn_pruefen.config(state="normal")
        self.test_eingabe.focus()
        self._blitz_zeit_rest = 5
        self._blitz_tick()

    def _blitz_tick(self):
        if self._blitz_zeit_rest <= 0:
            ui = self.ui
            vok = self.test_liste[self.test_index]
            wort_key = vok.get("nativ", "")
            self.test_falsch_n += 1
            self.test_streak = 0
            xp_v = self._xp_verlust()
            self._update_wort_stats(wort_key, richtig=False, xp=xp_v)
            self.lbl_test_feedback.config(text=t(ui, "blitz_abgelaufen"), fg=CLR["red"])
            self.test_eingabe.config(state="disabled")
            self.btn_pruefen.config(state="disabled")
            self.root.after(1200, lambda: (self.__dict__.update({"test_index": self.test_index+1}),
                                           self._blitz_naechste()))
            return
        self.lbl_blitz_timer.config(
            text=f"⏱ {self._blitz_zeit_rest}s",
            fg=CLR["red"] if self._blitz_zeit_rest <= 2 else CLR["orange"])
        self._blitz_zeit_rest -= 1
        self._blitz_after = self.root.after(1000, self._blitz_tick)

    def _blitz_pruefen(self):
        if self.test_eingabe.cget("state") == "disabled":
            return
        if self._blitz_after:
            self.root.after_cancel(self._blitz_after)
            self._blitz_after = None
        ui      = self.ui
        antwort = self.test_eingabe.get().strip().lower()
        vok     = self.test_liste[self.test_index]
        loesung = vok[self.test_key_loesung]
        wort_key = vok.get("nativ", "")

        if antwort == loesung.lower():
            self.test_richtig_n += 1
            self.test_streak += 1
            xp_g = self._xp_fuer_richtig()
            self._update_wort_stats(wort_key, richtig=True, xp=xp_g)
            self.lbl_test_feedback.config(
                text=t(ui, "test_richtig") + f"  +{xp_g} XP", fg="#27ae60")
            self.test_eingabe.config(state="disabled")
            self.btn_pruefen.config(state="disabled")
            self.test_index += 1
            self.root.after(700, self._blitz_naechste)
        else:
            self.test_falsch_n += 1
            self.test_streak = 0
            xp_v = self._xp_verlust()
            self._update_wort_stats(wort_key, richtig=False, xp=xp_v)
            self.lbl_test_feedback.config(
                text=t(ui, "test_falsch_end") + f"  -{xp_v} XP  ✓{loesung}",
                fg=CLR["red"])
            self.test_eingabe.config(state="disabled")
            self.btn_pruefen.config(state="disabled")
            self.test_index += 1
            self.root.after(1400, self._blitz_naechste)

    def zeige_mc(self, auswahl=None):
        self._session_starten()
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)

        self._aktuelle_ansicht = lambda: self.zeige_mc(auswahl=auswahl)
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("460x500")
            SKAL.setze_basis(460, 500)

        alle = vokabeln_laden(ls)
        vok_liste = auswahl if auswahl is not None else alle[:]
        if len(alle) < 4:
            messagebox.showinfo("", "Für Multiple Choice mindestens 4 Vokabeln nötig!")
            self.zeige_hauptmenue()
            return
        self.test_liste = vok_liste[:]
        random.shuffle(self.test_liste)
        self.test_index     = 0
        self.test_richtig_n = 0
        self.test_falsch_n  = 0
        self.test_streak    = 0
        self.xp_multiplikator    = 1.5 if hat_freischaltung("xp_multiplikator") else 1.0
        self.streak_bonus_aktiv  = hat_freischaltung("streak_bonus")

        tk.Label(self.root, text=t(ui, "mc_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(16, 4))

        self.lbl_test_nr = tk.Label(self.root, text="", font=fnt(11),
                                    bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_test_nr.pack()
        self.lbl_streak = tk.Label(self.root, text="", font=fnt(11, "bold"),
                                   bg=CLR["bg"], fg="#e74c3c")
        self.lbl_streak.pack()

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=SKAL.s(40), fill="x", pady=(8, 12))
        tk.Label(f_a, text=mutter.upper(), font=fnt(11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.lbl_mc_frage = tk.Label(f_a, text="", font=fnt(22, "bold"),
                                      bg=CLR["white"], fg=CLR["text"])
        self.lbl_mc_frage.pack(pady=(0, 10))

        self.lbl_test_feedback = tk.Label(self.root, text="", font=fnt(12),
                                          bg=CLR["bg"])
        self.lbl_test_feedback.pack()

        self.mc_btn_frame = make_frame(self.root)
        self.mc_btn_frame.pack(padx=SKAL.s(40), fill="x", pady=8)

        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self._test_zurueck).pack(pady=8)

        self._mc_naechste(alle)

    def _mc_naechste(self, alle):
        ui = self.ui
        if self.test_index >= len(self.test_liste):
            self._test_abschluss()
            return
        vok = self.test_liste[self.test_index]
        richtig = vok.get("lern", "")
        self.lbl_mc_frage.config(text=vok.get("nativ", ""))
        self.lbl_test_nr.config(
            text=t(ui, "test_frage", i=self.test_index+1, n=len(self.test_liste)))
        self.lbl_test_feedback.config(text="")
        if self.test_streak >= 5 and self.streak_bonus_aktiv:
            self.lbl_streak.config(text=t(ui, "streak", n=self.test_streak) + " 2x XP!")
        elif self.test_streak >= 3:
            self.lbl_streak.config(text=t(ui, "streak", n=self.test_streak))
        else:
            self.lbl_streak.config(text="")

        falsche = [v.get("lern","") for v in alle if v.get("lern","") != richtig]
        random.shuffle(falsche)
        optionen = [richtig] + falsche[:3]
        random.shuffle(optionen)

        for w in self.mc_btn_frame.winfo_children():
            w.destroy()

        for opt in optionen:
            btn = tk.Button(self.mc_btn_frame, text=opt, font=fnt(13, "bold"),
                            bg=CLR["white"], fg=CLR["text"],
                            relief="flat", bd=0,
                            highlightbackground=CLR["card_border"], highlightthickness=2,
                            padx=10, pady=10, cursor="hand2",
                            wraplength=340,
                            command=lambda o=opt, r=richtig, v=vok: self._mc_antwort(o, r, v, alle))
            btn.pack(fill="x", pady=3)

    def _mc_antwort(self, antwort, richtig, vok, alle):
        ui = self.ui
        wort_key = vok.get("nativ", "")
        if antwort == richtig:
            self.test_richtig_n += 1
            self.test_streak += 1
            xp_g = self._xp_fuer_richtig()
            self._update_wort_stats(wort_key, richtig=True, xp=xp_g)
            self.lbl_test_feedback.config(
                text=t(ui, "test_richtig") + f"  +{xp_g} XP", fg="#27ae60")
            for btn in self.mc_btn_frame.winfo_children():
                btn.config(state="disabled",
                           bg="#27ae60" if btn.cget("text") == richtig else CLR["white"])
            self.test_index += 1
            self.root.after(900, lambda: self._mc_naechste(alle))
        else:
            self.test_falsch_n += 1
            self.test_streak = 0
            xp_v = self._xp_verlust()
            self._update_wort_stats(wort_key, richtig=False, xp=xp_v)
            self.lbl_test_feedback.config(
                text=t(ui, "test_falsch_end") + f"  -{xp_v} XP", fg=CLR["red"])
            for btn in self.mc_btn_frame.winfo_children():
                btn.config(state="disabled",
                           bg="#27ae60" if btn.cget("text") == richtig else
                           (CLR["red"] if btn.cget("text") == antwort else CLR["white"]))
            self.test_index += 1
            self.root.after(1400, lambda: self._mc_naechste(alle))

    def zeige_bearbeiten(self):
        self._aktuelle_ansicht = self.zeige_bearbeiten
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("660x560")
            SKAL.setze_basis(660, 560)
        ui, ls = self.ui, self.ls

        tk.Label(self.root, text=t(ui, "bear_titel"), font=fnt(16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(16, 6))

        such_frame = make_frame(self.root)
        such_frame.pack(padx=SKAL.s(20), fill="x", pady=(0, 8))

        such_outer = tk.Frame(such_frame, bg=CLR["border"],
                              highlightbackground=CLR["border"], highlightthickness=2)
        such_outer.pack(fill="x")

        self.such_var  = tk.StringVar()
        such_entry = tk.Entry(such_outer, textvariable=self.such_var,
                              font=fnt(12, "bold"), fg=CLR["entry_fg"],
                              bg=CLR["entry_bg"],
                              bd=0, relief="flat", highlightthickness=0,
                              insertbackground=CLR["entry_ins"])
        such_entry.pack(fill="x", ipady=8, padx=SKAL.s(6))

        placeholder = t(ui, "bear_suche")
        such_entry.insert(0, placeholder)
        such_entry.config(fg=CLR["sub"])
        self._such_placeholder_aktiv = True

        def on_focus_in(e):
            if self._such_placeholder_aktiv:
                such_entry.delete(0, tk.END)
                such_entry.config(fg=CLR["entry_fg"])
                such_outer.config(highlightbackground=CLR["blue"])
                self._such_placeholder_aktiv = False

        def on_focus_out(e):
            if not such_entry.get().strip():
                such_entry.insert(0, placeholder)
                such_entry.config(fg=CLR["sub"])
                such_outer.config(highlightbackground=CLR["border"])
                self._such_placeholder_aktiv = True

        def on_key(_=None):
            if self._such_placeholder_aktiv:
                return
            q = such_entry.get().strip()
            self.bear_aufbauen(q)

        such_entry.bind("<FocusIn>",  on_focus_in)
        such_entry.bind("<FocusOut>", on_focus_out)
        such_entry.bind("<KeyRelease>", lambda e: self.root.after(10, on_key))

        container = make_frame(self.root)
        container.pack(padx=SKAL.s(16), fill="both", expand=True)
        canvas    = tk.Canvas(container, bg=CLR["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.scroll_frame = make_frame(canvas)
        self.scroll_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self.bear_canvas = canvas
        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            try:
                canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except Exception:
                pass
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        self.bear_aufbauen()

        btn_row = make_frame(self.root)
        btn_row.pack(pady=SKAL.s(8))
        tk.Button(btn_row, text="🎵 Alle fehlenden Audios laden", font=fnt(11, "bold"),
                  bg="#16a085", fg="white", relief="flat", padx=SKAL.s(12), pady=SKAL.s(8),
                  cursor="hand2", command=self.bear_audios_nachladen).pack(side="left", padx=SKAL.s(6))
        tk.Button(btn_row, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(side="left", padx=SKAL.s(6))

    def bear_audios_nachladen(self):
        ui, ls = self.ui, self.ls
        liste = vokabeln_laden(ls)
        fehlend = [i for i, v in enumerate(liste) if not v.get("audio", "").strip()]
        if not fehlend:
            messagebox.showinfo(t(ui, "bear_titel"), "Alle Vokabeln haben bereits ein Audio 🎵")
            return

        popup = tk.Toplevel(self.root)
        popup.title("Audios werden geladen …")
        popup.configure(bg=CLR["popup_bg"])
        popup.transient(self.root)
        popup.grab_set()
        popup.resizable(False, False)

        lbl_status = tk.Label(popup, text=f"0 / {len(fehlend)}",
                              font=("Arial", 13, "bold"),
                              bg=CLR["popup_bg"], fg=CLR["text"])
        lbl_status.pack(padx=30, pady=(24, 8))

        lbl_detail = tk.Label(popup, text="", font=("Arial", 10),
                              bg=CLR["popup_bg"], fg=CLR["sub"],
                              wraplength=320)
        lbl_detail.pack(padx=30, pady=(0, 20))

        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 190
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 60
        popup.geometry(f"380x140+{x}+{y}")

        abgebrochen = {"flag": False}
        popup.protocol("WM_DELETE_WINDOW", lambda: abgebrochen.__setitem__("flag", True))

        def worker():
            erfolgreich = 0
            liste_aktuell = vokabeln_laden(ls)
            for n, i in enumerate(fehlend, start=1):
                if abgebrochen["flag"]:
                    break
                if i >= len(liste_aktuell):
                    continue
                vok = liste_aktuell[i]
                wort = vok.get("lern", "")

                def update_ui(n=n, wort=wort):
                    lbl_status.config(text=f"{n} / {len(fehlend)}")
                    lbl_detail.config(text=wort)
                try:
                    self.root.after(0, update_ui)
                except Exception:
                    pass

                if not vok.get("audio", "").strip() and wort.strip():
                    auto_name = gtts_dateiname(wort, ls)
                    if gtts_herunterladen(wort, ls, auto_name):
                        liste_aktuell[i]["audio"] = auto_name
                        erfolgreich += 1
                        vokabeln_speichern(ls, liste_aktuell)

            def fertig():
                try:
                    popup.destroy()
                except Exception:
                    pass
                self.bear_aufbauen(self.such_var.get().strip()
                                   if hasattr(self, "such_var") and not getattr(self, "_such_placeholder_aktiv", True)
                                   else "")
                messagebox.showinfo(t(ui, "bear_titel"),
                                     f"{erfolgreich} von {len(fehlend)} Audios geladen ✅")
            try:
                self.root.after(0, fertig)
            except Exception:
                pass

        threading.Thread(target=worker, daemon=True).start()

    def bear_aufbauen(self, suche=""):
        ui, ls = self.ui, self.ls
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)

        for w in self.scroll_frame.winfo_children():
            w.destroy()

        alle  = vokabeln_laden(ls)
        alle_sortiert = sorted(alle, key=lambda v: v.get("nativ","").lower())

        q     = suche.lower().strip()
        liste = [v for v in alle_sortiert
                 if q in v.get("nativ","").lower() or q in v.get("lern","").lower()] \
                if q else alle_sortiert

        hdr = tk.Frame(self.scroll_frame, bg=CLR["hdr_bg"])
        hdr.pack(fill="x", pady=(0, 2))
        for txt, w in [(mutter, 13), (nativname(ls), 13),
                       ("Audio", 5), (t(ui,"bear_aktion"), 20)]:
            tk.Label(hdr, text=txt, font=fnt(11, "bold"),
                     bg=CLR["hdr_bg"], fg=CLR["hdr_fg"], width=w, anchor="w").pack(side="left", padx=SKAL.s(6), pady=SKAL.s(5))

        if not liste:
            msg = t(ui, "bear_keine_treffer", q=suche) if suche else t(ui, "bear_leer")
            tk.Label(self.scroll_frame, text=msg,
                     font=fnt(12), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=SKAL.s(20))
            return

        def orig_idx(vok):
            for i, v in enumerate(alle):
                if v is vok:
                    return i
            return -1

        for i, vok in enumerate(liste):
            idx = orig_idx(vok)
            bg  = CLR["row_a"] if i % 2 == 0 else CLR["row_b"]
            zeile = tk.Frame(self.scroll_frame, bg=bg,
                             highlightbackground=CLR["card_border"], highlightthickness=2)
            zeile.pack(fill="x", pady=SKAL.s(1))
            tk.Label(zeile, text=vok.get("nativ",""), font=fnt(11, "bold"),
                     bg=bg, fg=CLR["text"], width=13, anchor="w").pack(side="left", padx=SKAL.s(6), pady=SKAL.s(5))
            tk.Label(zeile, text=vok.get("lern",""), font=fnt(11, "bold"),
                     bg=bg, fg=CLR["text"], width=13, anchor="w").pack(side="left", padx=SKAL.s(6))

            hat_audio = bool(vok.get("audio",""))
            tk.Label(zeile, text="🎵" if hat_audio else "—", font=fnt(12),
                     bg=bg, fg=CLR["green"] if hat_audio else CLR["sub"],
                     width=5).pack(side="left", padx=SKAL.s(4))

            btn_r = tk.Frame(zeile, bg=bg)
            btn_r.pack(side="left", padx=SKAL.s(6))
            tk.Button(btn_r, text=t(ui,"bear_aendern"), font=fnt(10, "bold"),
                      bg=CLR["purple"], fg="white", relief="flat", padx=SKAL.s(7), pady=SKAL.s(3),
                      cursor="hand2",
                      command=lambda i=idx: self.bear_aendern(i)).pack(side="left", padx=SKAL.s(2))
            tk.Button(btn_r, text=t(ui,"bear_loeschen"), font=fnt(10, "bold"),
                      bg=CLR["red"], fg="white", relief="flat", padx=SKAL.s(7), pady=SKAL.s(3),
                      cursor="hand2",
                      command=lambda i=idx: self.bear_loeschen(i)).pack(side="left", padx=SKAL.s(2))

    def bear_aendern(self, index):
        ui, ls = self.ui, self.ls
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)
        liste  = vokabeln_laden(ls)
        vok    = liste[index]

        popup = tk.Toplevel(self.root)
        popup.title(t(ui, "bear_dlg_titel"))
        popup.resizable(False, False)
        popup.configure(bg=CLR["popup_bg"])
        popup.grab_set()

        def lbl(txt):
            tk.Label(popup, text=txt, font=("Arial", 11, "bold"),
                     bg=CLR["popup_bg"], fg=CLR["text"]).pack(pady=(14, 4), padx=30, anchor="w")

        def eingabe_kasten(parent, initial_value=""):
            outer = tk.Frame(parent, bg=CLR["blue"])
            outer.pack(fill="x", padx=30, pady=(0, 4))
            inner = tk.Frame(outer, bg=CLR["entry_bg"])
            inner.pack(fill="x", padx=2, pady=2)
            entry = tk.Entry(inner, font=("Arial", 14, "bold"), fg=CLR["entry_fg"],
                             bg=CLR["entry_bg"], insertbackground=CLR["entry_ins"],
                             bd=0, highlightthickness=0, relief="flat")
            entry.pack(fill="x", padx=8, pady=8)
            entry.insert(0, initial_value)

            def on_focus_in(e):
                outer.config(bg=CLR["blue"])
            def on_focus_out(e):
                outer.config(bg=CLR["border"])

            outer.config(bg=CLR["border"])
            entry.bind("<FocusIn>",  on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)
            return entry

        lbl(f"{mutter}:")
        ein_a = eingabe_kasten(popup, vok.get("nativ",""))

        lbl(t(ui, "bear_dlg_b", lang=lsname))
        ein_b = eingabe_kasten(popup, vok.get("lern",""))

        lbl(t(ui, "bear_dlg_audio"))
        audio_var = tk.StringVar(value=vok.get("audio",""))
        af = tk.Frame(popup, bg=CLR["popup_bg"])
        af.pack(fill="x", padx=30, pady=(0, 6))

        def kurz(pfad):
            return os.path.basename(pfad) if pfad else "(keine)"

        audio_lbl = tk.Label(af, text=kurz(audio_var.get()),
                             font=("Arial", 9, "bold"), bg=CLR["popup_bg"], fg=CLR["text"],
                             anchor="w", width=28)
        audio_lbl.pack(side="left")

        def waehle_audio():
            pfad = filedialog.askopenfilename(
                title="MP3 aus audio/-Ordner wählen",
                initialdir=AUDIO_DIR,
                filetypes=[("MP3-Dateien", "*.mp3"), ("Alle Dateien", "*.*")])
            if pfad:
                name = os.path.basename(pfad)
                audio_var.set(name)
                audio_lbl.config(text=name)

        tk.Button(af, text=t(ui, "bear_dlg_audio_btn"), font=("Arial", 10, "bold"),
                  bg=CLR["blue"], fg="white", relief="flat", padx=8, pady=3,
                  cursor="hand2", command=waehle_audio).pack(side="left", padx=6)

        def speichern():
            a_neu = ein_a.get().strip()
            b_neu = ein_b.get().strip()
            if a_neu and b_neu:
                audio_neu = audio_var.get().strip()
                if not audio_neu:
                    auto_name = gtts_dateiname(b_neu, ls)
                    if gtts_herunterladen(b_neu, ls, auto_name):
                        audio_neu = auto_name
                liste[index] = {"nativ": a_neu, "lern": b_neu,
                                "audio": audio_neu}
                vokabeln_speichern(ls, liste)
                popup.destroy()
                self.bear_aufbauen()

        btn_r = tk.Frame(popup, bg=CLR["popup_bg"])
        btn_r.pack(pady=(8, 18))
        tk.Button(btn_r, text=t(ui,"bear_dlg_save"), font=("Arial", 11, "bold"),
                  bg=CLR["purple"], fg="white", relief="flat", padx=16, pady=6,
                  cursor="hand2", command=speichern).pack(side="left", padx=6)
        tk.Button(btn_r, text=t(ui,"bear_dlg_abbruch"), font=("Arial", 11, "bold"),
                  bg=CLR["gray"], fg=CLR["text"], relief="flat", padx=14, pady=6,
                  cursor="hand2", command=popup.destroy).pack(side="left", padx=6)

        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 200
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 180
        popup.geometry(f"400x420+{x}+{y}")
        ein_a.focus()
        popup.bind("<Return>", lambda e: speichern())

    def bear_loeschen(self, index):
        ui, ls = self.ui, self.ls
        liste  = vokabeln_laden(ls)
        wort   = liste[index].get("nativ","")
        if messagebox.askyesno(t(ui,"bear_del_titel"), t(ui,"bear_del_frage", w=wort)):
            liste.pop(index)
            vokabeln_speichern(ls, liste)
            self.bear_aufbauen()

    def zeige_statistik(self):
        self._aktuelle_ansicht = self.zeige_statistik
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("500x620")
            SKAL.setze_basis(500, 620)
        ui = self.ui
        s  = stats_laden()

        richtig = s.get("richtig", 0)
        falsch  = s.get("falsch",  0)
        gesamt  = richtig + falsch
        genau   = f"{int(richtig/gesamt*100)} %" if gesamt else "—"

        sek = s.get("lernzeit_sek", 0)
        zeit_str = f"{sek // 60} {t(ui,'stat_min')}" if sek < 3600 \
                   else f"{sek/3600:.1f} {t(ui,'stat_std')}"

        xp  = s.get("level_xp", 0)
        lvl, xp_ak, xp_nx = xp_fortschritt(xp)

        tk.Button(self.root, text=t(ui,"zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(pady=(10, 0))

        tk.Label(self.root, text=t(ui, "stat_titel"), font=fnt(17, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(10, 12))

        lvl_f = tk.Frame(self.root, bg=CLR["xp"])
        lvl_f.pack(padx=SKAL.s(40), fill="x", pady=(0, 12))
        tk.Label(lvl_f, text=f"⭐  {t(ui,'stat_level')} {lvl}",
                 font=fnt(22, "bold"), bg=CLR["xp"], fg="white").pack(pady=(12, 2))
        tk.Label(lvl_f,
                 text=f"{xp_ak} / {xp_nx} XP  →  {t(ui,'stat_naechstes')}: {t(ui,'stat_level')} {lvl+1}",
                 font=fnt(10), bg=CLR["xp"], fg="white").pack(pady=(0, 6))
        bar_bg = tk.Frame(lvl_f, bg="white", height=SKAL.s(10), width=360)
        bar_bg.pack(pady=(0, 12))
        bar_bg.pack_propagate(False)
        perc  = xp_ak / xp_nx if xp_nx else 1
        bar_w = int(360 * perc)
        if bar_w > 0:
            tk.Frame(bar_bg, bg="#e67e22", height=SKAL.s(10), width=bar_w).place(x=0, y=0)

        def stat_row(label, wert, col=CLR["text"]):
            f = tk.Frame(self.root, bg=CLR["white"],
                         highlightbackground=CLR["card_border"], highlightthickness=2)
            f.pack(padx=SKAL.s(40), fill="x", pady=SKAL.s(3))
            tk.Label(f, text=label, font=fnt(11, "bold"), bg=CLR["white"],
                     fg=CLR["text"], anchor="w").pack(side="left", padx=SKAL.s(12), pady=SKAL.s(8))
            tk.Label(f, text=wert, font=fnt(13, "bold"), bg=CLR["white"],
                     fg=col, anchor="e").pack(side="right", padx=SKAL.s(12))

        stat_row(t(ui,"stat_richtig"),    str(richtig), "#27ae60")
        stat_row(t(ui,"stat_falsch"),     str(falsch),  CLR["red"])
        stat_row(t(ui,"stat_genauigkeit"), genau,       CLR["blue"])
        stat_row(t(ui,"stat_lernzeit"),   zeit_str,     CLR["orange"])
        stat_row(t(ui,"stat_xp"),         str(xp),      CLR["xp"])

        tk.Label(self.root, text=t(ui,"stat_top_falsch"), font=fnt(12, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(14, 4))

        ws = s.get("wort_stats", {})
        if not ws:
            tk.Label(self.root, text=t(ui,"stat_keine"),
                     font=fnt(11, "bold"), bg=CLR["bg"], fg=CLR["text"]).pack()
        else:
            sortiert = sorted(ws.items(),
                              key=lambda kv: kv[1].get("falsch",0), reverse=True)[:5]
            for wort, st in sortiert:
                r2, f2 = st.get("richtig",0), st.get("falsch",0)
                ff = tk.Frame(self.root, bg=CLR["white"],
                              highlightbackground=CLR["card_border"], highlightthickness=2)
                ff.pack(padx=SKAL.s(40), fill="x", pady=SKAL.s(2))
                tk.Label(ff, text=wort, font=fnt(11, "bold"),
                         bg=CLR["white"], fg=CLR["text"], anchor="w").pack(side="left", padx=SKAL.s(10), pady=SKAL.s(6))
                tk.Label(ff, text=f"✓{r2}  ✗{f2}",
                         font=fnt(10, "bold"), bg=CLR["white"], fg=CLR["text"],
                         anchor="e").pack(side="right", padx=SKAL.s(10))

    def zeige_freischaltungen(self):
        self._aktuelle_ansicht = self.zeige_freischaltungen
        self.clear()
        if self.root.winfo_width() <= 1:
            self.root.geometry("540x680")
            SKAL.setze_basis(540, 680)
        ui = self.ui
        s  = stats_laden()
        xp  = s.get("level_xp", 0)
        lvl = berechne_level(xp)

        tk.Label(self.root, text=t(ui, "freisch_titel"), font=fnt(17, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(18, 2))
        tk.Label(self.root, text=f"⭐ {t(ui,'stat_level')} {lvl}",
                 font=fnt(13, "bold"), bg=CLR["bg"], fg=CLR["xp"]).pack(pady=(0, 8))

        container = make_frame(self.root)
        container.pack(padx=SKAL.s(16), fill="both", expand=True)
        canvas    = tk.Canvas(container, bg=CLR["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        sf = make_frame(canvas)
        sf.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=sf, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            try:
                canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except Exception:
                pass
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        def aufbauen():
            for w in sf.winfo_children():
                w.destroy()

            s2       = stats_laden()
            frei2    = get_freigeschaltet(s2)
            aktiv2   = get_aktiviert(s2)

            for (req_lvl, key, beschr, icon) in FREISCHALTUNGEN[ui]:
                ist_frei   = key in frei2
                ist_aktiv  = key in aktiv2
                gesperrt   = not ist_frei

                if gesperrt:
                    bg_card = CLR["gray"]
                    fg_card = CLR["sub"]
                    border  = CLR["border"]
                elif ist_aktiv:
                    bg_card = CLR["white"]
                    fg_card = CLR["text"]
                    border  = "#27ae60"
                else:
                    bg_card = CLR["white"]
                    fg_card = CLR["text"]
                    border  = CLR["blue"]

                card = tk.Frame(sf, bg=bg_card,
                                highlightbackground=border, highlightthickness=2)
                card.pack(fill="x", padx=SKAL.s(10), pady=SKAL.s(5))

                top = tk.Frame(card, bg=bg_card)
                top.pack(fill="x", padx=SKAL.s(12), pady=(10, 4))

                tk.Label(top, text=icon, font=fnt(20), bg=bg_card).pack(side="left", padx=(0, 10))

                info = tk.Frame(top, bg=bg_card)
                info.pack(side="left", fill="x", expand=True)

                tk.Label(info, text=beschr, font=fnt(11, "bold"),
                         bg=bg_card, fg=fg_card, anchor="w", wraplength=280).pack(anchor="w")

                if gesperrt:
                    tk.Label(info, text=t(ui, "freisch_gesperrt", lvl=req_lvl),
                             font=fnt(10, "bold"), bg=bg_card, fg=CLR["sub"], anchor="w").pack(anchor="w")
                else:
                    status_txt = t(ui, "freisch_an") if ist_aktiv else t(ui, "freisch_aus")
                    tk.Label(info, text=f"{t(ui, 'freisch_frei')}  ·  {status_txt}",
                             font=fnt(10, "bold"),
                             bg=bg_card,
                             fg="#27ae60" if ist_aktiv else CLR["sub"],
                             anchor="w").pack(anchor="w")

                if not gesperrt:
                    btn_txt  = t(ui, "freisch_deaktivieren") if ist_aktiv else t(ui, "freisch_aktivieren")
                    btn_col  = "#e74c3c" if ist_aktiv else "#27ae60"

                    def mache_toggle(k=key):
                        an = toggle_aktivierung(k)
                        if k == "thema_nacht":
                            if an:
                                CLR.update(CLR_DARK)
                            else:
                                CLR.update(CLR_LIGHT)
                            self.root.configure(bg=CLR["bg"])
                        aufbauen()

                    tk.Button(top, text=btn_txt,
                              font=fnt(10, "bold"),
                              bg=btn_col, fg="white", relief="flat",
                              padx=SKAL.s(12), pady=SKAL.s(6), cursor="hand2",
                              command=mache_toggle).pack(side="right", padx=(8, 0))

                if gesperrt:
                    prog = min(1.0, lvl / req_lvl)
                    bar_bg_f = tk.Frame(card, bg=CLR["border"], height=SKAL.s(6), width=460)
                    bar_bg_f.pack(padx=SKAL.s(12), pady=(0, 4))
                    bar_bg_f.pack_propagate(False)
                    bar_w = int(460 * prog)
                    if bar_w > 0:
                        tk.Frame(bar_bg_f, bg=CLR["xp"], height=SKAL.s(6), width=bar_w).place(x=0, y=0)
                    tk.Label(card, text=f"Level {lvl} / {req_lvl}",
                             font=fnt(9, "bold"), bg=bg_card, fg=CLR["sub"]).pack(anchor="e", padx=SKAL.s(12), pady=(0, 6))
                else:
                    tk.Frame(card, bg=bg_card, height=SKAL.s(6)).pack()

        aufbauen()

        tk.Button(self.root, text=t(ui, "zurueck"), font=fnt(12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=SKAL.s(14), pady=SKAL.s(8),
                  cursor="hand2", command=self.zeige_hauptmenue).pack(pady=(8, 4))

    # ─── GANZE SÄTZE ───────────────────────────────────────
    def zeige_saetze_menue(self):
        self.clear()
        self.root.geometry("460x460")
        ui, ls = self.ui, self.ls

        tk.Label(self.root, text=t(ui, "saetze_titel"), font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(28, 4))

        saetze = saetze_laden(ls)
        tk.Label(self.root, text=t(ui, "saetze_gespeichert", n=len(saetze)),
                 font=("Arial", 11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(0, 20))

        btn_cfg = {"font": ("Arial", 13, "bold"), "relief": "flat",
                   "padx": 0, "pady": 13, "cursor": "hand2", "width": 22}
        tk.Button(self.root, text=t(ui, "saetze_ein_titel"), bg=CLR["blue"], fg="white",
                  command=self.zeige_saetze_eintragen, **btn_cfg).pack(pady=4)
        tk.Button(self.root, text=t(ui, "saetze_lern_titel"), bg=CLR["green"], fg="white",
                  command=self.zeige_saetze_richtung_lernen, **btn_cfg).pack(pady=4)
        tk.Button(self.root, text=t(ui, "saetze_test_titel"), bg="#d35400", fg="white",
                  command=self.zeige_saetze_richtung_test, **btn_cfg).pack(pady=4)
        tk.Button(self.root, text=t(ui, "saetze_bear_btn"), bg=CLR["purple"], fg="white",
                  command=self.zeige_saetze_bearbeiten, **btn_cfg).pack(pady=4)
        tk.Button(self.root, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=14, pady=8,
                  cursor="hand2", command=self.zeige_hauptmenue).pack(pady=(16, 0))

    def zeige_saetze_richtung_lernen(self):
        ui, ls = self.ui, self.ls
        saetze = saetze_laden(ls)
        if not saetze:
            messagebox.showinfo(t(ui, "saetze_kein_titel"), t(ui, "saetze_kein"))
            return
        self.clear()
        self.root.geometry("460x360")
        mutter  = muttersprache_label(ui)
        lsname  = langname(ui, ls)
        flag_ls = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ls]
        flag_ui = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ui]

        tk.Label(self.root, text="📚  Sätze Lernen", font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(28, 4))
        tk.Label(self.root, text=t(ui, "richtung_titel"),
                 font=("Arial", 11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(0, 14))

        def karte(zeile1, zeile2, col, cb):
            f = tk.Frame(self.root, bg=CLR["white"],
                         highlightbackground=col, highlightthickness=2, cursor="hand2")
            f.pack(padx=40, fill="x", pady=6)
            inner = tk.Frame(f, bg=CLR["white"])
            inner.pack(padx=16, pady=13)
            l1 = tk.Label(inner, text=zeile1, font=("Arial", 13, "bold"),
                          bg=CLR["white"], fg=CLR["text"])
            l1.pack()
            l2 = tk.Label(inner, text=zeile2, font=("Arial", 10),
                          bg=CLR["white"], fg=CLR["sub"])
            l2.pack()
            for w in [f, inner, l1, l2]:
                w.bind("<Button-1>", lambda e: cb())

        karte(f"{flag_ui} {mutter}   →   {flag_ls} {lsname}",
              "Deutsch sehen, Übersetzung aufdecken", CLR["green"],
              lambda: self.zeige_saetze_lernen(umgekehrt=False))
        karte(f"{flag_ls} {lsname}   →   {flag_ui} {mutter}",
              "Übersetzung sehen, Deutsch aufdecken", CLR["orange"],
              lambda: self.zeige_saetze_lernen(umgekehrt=True))

        tk.Button(self.root, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=20, pady=10,
                  cursor="hand2", command=self.zeige_saetze_menue).pack(pady=(10, 6))

    def zeige_saetze_richtung_test(self):
        ui, ls = self.ui, self.ls
        saetze = saetze_laden(ls)
        if not saetze:
            messagebox.showinfo(t(ui, "saetze_kein_titel"), t(ui, "saetze_kein"))
            return
        self.clear()
        self.root.geometry("460x360")
        mutter  = muttersprache_label(ui)
        lsname  = langname(ui, ls)
        flag_ls = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ls]
        flag_ui = {"de": "🇩🇪", "en": "🇬🇧", "fi": "🇫🇮"}[ui]

        tk.Label(self.root, text=t(ui, "saetze_test_titel"), font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(28, 4))
        tk.Label(self.root, text=t(ui, "richtung_titel"),
                 font=("Arial", 11), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(0, 14))

        def karte(zeile1, zeile2, col, cb):
            f = tk.Frame(self.root, bg=CLR["white"],
                         highlightbackground=col, highlightthickness=2, cursor="hand2")
            f.pack(padx=40, fill="x", pady=6)
            inner = tk.Frame(f, bg=CLR["white"])
            inner.pack(padx=16, pady=13)
            l1 = tk.Label(inner, text=zeile1, font=("Arial", 13, "bold"),
                          bg=CLR["white"], fg=CLR["text"])
            l1.pack()
            l2 = tk.Label(inner, text=zeile2, font=("Arial", 10),
                          bg=CLR["white"], fg=CLR["sub"])
            l2.pack()
            for w in [f, inner, l1, l2]:
                w.bind("<Button-1>", lambda e: cb())

        karte(f"{flag_ui} {mutter}   →   {flag_ls} {lsname}",
              f"{lsname} eintippen", CLR["green"],
              lambda: self._saetze_sprache_abfragen(False))
        karte(f"{flag_ls} {lsname}   →   {flag_ui} {mutter}",
              f"{mutter} eintippen", CLR["orange"],
              lambda: self._saetze_sprache_abfragen(True))

        tk.Button(self.root, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=20, pady=10,
                  cursor="hand2", command=self.zeige_saetze_menue).pack(pady=(10, 6))

    def _saetze_sprache_abfragen(self, umgekehrt):
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)
        lsname = langname(ui, ls)
        popup = tk.Toplevel(self.root)
        popup.title("Schreibsprache wählen")
        popup.resizable(False, False)
        popup.configure(bg=CLR["popup_bg"])
        popup.grab_set()
        tk.Label(popup, text="✏️  In welcher Sprache schreiben?",
                 font=("Arial", 13, "bold"), bg=CLR["popup_bg"], fg=CLR["text"]).pack(pady=(22, 12), padx=30)
        def starten(deutsch):
            popup.destroy()
            self._satz_schreibe_deutsch = deutsch
            self.zeige_saetze_test(umgekehrt=umgekehrt)
        btn_cfg = {"font": ("Arial", 12, "bold"), "relief": "flat",
                   "padx": 0, "pady": 12, "cursor": "hand2", "width": 22}
        tk.Button(popup, text="🇩🇪   Deutsch", bg=CLR["blue"], fg="white",
                  command=lambda: starten(True), **btn_cfg).pack(pady=4)
        tk.Button(popup, text=f"🇫🇮   {lsname}", bg=CLR["red"], fg="white",
                  command=lambda: starten(False), **btn_cfg).pack(pady=(4, 20))
        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 175
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 110
        popup.geometry(f"350x220+{x}+{y}")

    def zeige_saetze_lernen(self, umgekehrt=False):
        ui, ls = self.ui, self.ls
        saetze = saetze_laden(ls)
        if not saetze:
            messagebox.showinfo(t(ui, "saetze_kein_titel"), t(ui, "saetze_kein"))
            return
        self._session_starten()
        self.clear()
        self.root.geometry("560x500")
        mutter = muttersprache_label(ui)
        lsname = langname(ui, ls)

        self.satz_lern_liste     = saetze[:]
        random.shuffle(self.satz_lern_liste)
        self.satz_lern_index     = 0
        self.satz_lern_aufgedeckt = False
        self.satz_lern_umgekehrt  = umgekehrt
        self.satz_lern_audio_gespielt = False

        if umgekehrt:
            self.satz_lern_key_oben  = "lern"
            self.satz_lern_key_unten = "nativ"
            label_oben  = nativname(ls).upper()
        else:
            self.satz_lern_key_oben  = "nativ"
            self.satz_lern_key_unten = "lern"
            label_oben  = mutter.upper()

        tk.Label(self.root, text="📚  Sätze Lernen", font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(16, 2))
        tk.Label(self.root, text="🔴 Audio abspielen ist Pflicht vor dem Weitergehen!",
                 font=("Arial", 10, "bold"), bg=CLR["bg"], fg=CLR["red"]).pack(pady=(0, 8))

        self.lbl_satz_lern_nr = tk.Label(self.root, text="", font=("Arial", 11),
                                          bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_satz_lern_nr.pack()

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=20, fill="x", pady=(6, 6))
        tk.Label(f_a, text=label_oben, font=("Arial", 10, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(6, 2))
        self.lbl_satz_lern_a = tk.Label(f_a, text="", font=("Arial", 14, "bold"),
                                         bg=CLR["white"], fg=CLR["text"],
                                         wraplength=480, justify="center")
        self.lbl_satz_lern_a.pack(padx=12, pady=(0, 10))

        self.f_satz_lern_b = tk.Frame(self.root, bg=CLR["light"],
                                       highlightbackground=CLR["card_border"], highlightthickness=2,
                                       cursor="hand2")
        self.f_satz_lern_b.pack(padx=20, fill="x", pady=(0, 10))
        self.lbl_satz_lern_b = tk.Label(self.f_satz_lern_b,
                                         text="❓  Klicken zum Aufdecken",
                                         font=("Arial", 13), bg=CLR["light"], fg=CLR["sub"])
        self.lbl_satz_lern_b.pack(pady=(10, 14))
        for w in [self.f_satz_lern_b, self.lbl_satz_lern_b]:
            w.bind("<Button-1>", lambda e: self._satz_lern_toggle())

        row = make_frame(self.root)
        row.pack(pady=6)
        self.btn_satz_lern_audio = tk.Button(row, text="▶  Audio PFLICHT",
                                              font=("Arial", 12, "bold"),
                                              bg=CLR["red"], fg="white", relief="flat",
                                              padx=14, pady=8, cursor="hand2",
                                              command=self._satz_lern_play_audio)
        self.btn_satz_lern_audio.pack(side="left", padx=4)

        self.btn_satz_lern_weiter = tk.Button(row, text=t(ui, "weiter"),
                                               font=("Arial", 12, "bold"),
                                               bg=CLR["gray"], fg=CLR["sub"], relief="flat",
                                               padx=20, pady=8, cursor="hand2",
                                               command=self._satz_lern_weiter,
                                               state="disabled")
        self.btn_satz_lern_weiter.pack(side="left", padx=4)

        tk.Button(self.root, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=20, pady=8,
                  cursor="hand2", command=self._satz_lern_zurueck).pack(pady=(4, 0))

        self._satz_lern_zeige()

    def _satz_lern_zeige(self):
        ui = self.ui
        if self.satz_lern_index >= len(self.satz_lern_liste):
            self._session_beenden()
            messagebox.showinfo("🎉", f"Du hast alle {len(self.satz_lern_liste)} Sätze durchgelernt!")
            self.zeige_saetze_menue()
            return
        satz = self.satz_lern_liste[self.satz_lern_index]
        self.lbl_satz_lern_nr.config(
            text=f"Satz {self.satz_lern_index+1} von {len(self.satz_lern_liste)}")
        self.lbl_satz_lern_a.config(text=satz[self.satz_lern_key_oben])
        self.satz_lern_aufgedeckt = False
        self.satz_lern_audio_gespielt = False
        self.btn_satz_lern_audio.config(bg=CLR["red"], text="▶  Audio PFLICHT")
        self.btn_satz_lern_weiter.config(state="disabled", bg=CLR["gray"], fg=CLR["sub"])
        self.lbl_satz_lern_b.config(text="❓  Klicken zum Aufdecken",
                                     fg=CLR["sub"], font=("Arial", 13))
        self.f_satz_lern_b.config(bg=CLR["light"])
        self.lbl_satz_lern_b.config(bg=CLR["light"])

    def _satz_lern_play_audio(self):
        ui = self.ui
        if not PYGAME_OK:
            messagebox.showinfo("Audio", "pygame nicht installiert.\npip install pygame")
            return
        if self.satz_lern_index >= len(self.satz_lern_liste):
            return
        satz      = self.satz_lern_liste[self.satz_lern_index]
        dateiname = satz.get("audio", "")
        pfad      = audio_pfad(dateiname)
        if pfad and os.path.exists(pfad):
            try:
                pygame.mixer.music.load(pfad)
                pygame.mixer.music.play()
                self.satz_lern_audio_gespielt = True
                self.btn_satz_lern_audio.config(bg="#16a085", text="▶  Audio ✓")
                self.btn_satz_lern_weiter.config(state="normal", bg=CLR["green"], fg="white")
            except Exception as e:
                messagebox.showerror("Audio", str(e))
        else:
            self.satz_lern_audio_gespielt = True
            self.btn_satz_lern_audio.config(bg=CLR["sub"], text="▶  Kein Audio")
            self.btn_satz_lern_weiter.config(state="normal", bg=CLR["green"], fg="white")
            messagebox.showinfo("Audio",
                f"Kein Audio für diesen Satz.\n\nAudio-Dateien bitte in den Ordner:\n{AUDIO_DIR}")

    def _satz_lern_toggle(self):
        if self.satz_lern_index >= len(self.satz_lern_liste):
            return
        satz = self.satz_lern_liste[self.satz_lern_index]
        if not self.satz_lern_aufgedeckt:
            self.lbl_satz_lern_b.config(text=satz[self.satz_lern_key_unten],
                                         fg=CLR["text"], font=("Arial", 14, "bold"))
            self.f_satz_lern_b.config(bg=CLR["white"])
            self.lbl_satz_lern_b.config(bg=CLR["white"])
            self.satz_lern_aufgedeckt = True
        else:
            self.lbl_satz_lern_b.config(text="❓  Klicken zum Aufdecken",
                                         fg=CLR["sub"], font=("Arial", 13))
            self.f_satz_lern_b.config(bg=CLR["light"])
            self.lbl_satz_lern_b.config(bg=CLR["light"])
            self.satz_lern_aufgedeckt = False

    def _satz_lern_weiter(self):
        if not self.satz_lern_audio_gespielt:
            messagebox.showwarning("Audio Pflicht!",
                "Bitte zuerst das Audio abspielen!\n(▶ Audio PFLICHT Button)")
            return
        self.satz_lern_index += 1
        self._satz_lern_zeige()

    def _satz_lern_zurueck(self):
        self._session_beenden()
        self.zeige_saetze_menue()

    def zeige_saetze_bearbeiten(self):
        ui, ls = self.ui, self.ls
        self.clear()
        self.root.geometry("660x560")

        tk.Label(self.root, text=t(ui, "saetze_bear_titel"), font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(16, 6))

        container = make_frame(self.root)
        container.pack(padx=16, fill="both", expand=True)
        canvas    = tk.Canvas(container, bg=CLR["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.satz_scroll_frame = make_frame(canvas)
        self.satz_scroll_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.satz_scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        self._saetze_bear_aufbauen()

        tk.Button(self.root, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=14, pady=8,
                  cursor="hand2", command=self.zeige_saetze_menue).pack(pady=8)

    def _saetze_bear_aufbauen(self):
        ui, ls = self.ui, self.ls
        mutter = muttersprache_label(ui)

        for w in self.satz_scroll_frame.winfo_children():
            w.destroy()

        liste = saetze_laden(ls)

        if not liste:
            tk.Label(self.satz_scroll_frame, text=t(ui, "saetze_bear_leer"),
                     font=("Arial", 12), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=20)
            return

        hdr = tk.Frame(self.satz_scroll_frame, bg=CLR["hdr_bg"])
        hdr.pack(fill="x", pady=(0, 2))
        for txt, w in [(mutter, 15), (nativname(ls), 15), ("Audio", 5), (t(ui, "saetze_bear_aktion"), 14)]:
            tk.Label(hdr, text=txt, font=("Arial", 11, "bold"),
                     bg=CLR["hdr_bg"], fg=CLR["hdr_fg"], width=w, anchor="w").pack(side="left", padx=6, pady=5)

        for i, satz in enumerate(liste):
            bg = CLR["row_a"] if i % 2 == 0 else CLR["row_b"]
            zeile = tk.Frame(self.satz_scroll_frame, bg=bg,
                             highlightbackground=CLR["card_border"], highlightthickness=2)
            zeile.pack(fill="x", pady=1)
            tk.Label(zeile, text=satz.get("nativ", ""), font=("Arial", 11, "bold"),
                     bg=bg, fg=CLR["text"], width=15, anchor="w",
                     wraplength=180).pack(side="left", padx=6, pady=5)
            tk.Label(zeile, text=satz.get("lern", ""), font=("Arial", 11, "bold"),
                     bg=bg, fg=CLR["text"], width=15, anchor="w",
                     wraplength=180).pack(side="left", padx=6)
            hat_audio = bool(satz.get("audio", ""))
            tk.Label(zeile, text="🎵" if hat_audio else "—", font=("Arial", 12),
                     bg=bg, fg=CLR["green"] if hat_audio else CLR["sub"],
                     width=5).pack(side="left", padx=4)
            btn_r = tk.Frame(zeile, bg=bg)
            btn_r.pack(side="left", padx=6)
            tk.Button(btn_r, text=t(ui, "saetze_bear_aendern"), font=("Arial", 10, "bold"),
                      bg=CLR["purple"], fg="white", relief="flat", padx=7, pady=3,
                      cursor="hand2",
                      command=lambda idx=i: self._satz_aendern(idx)).pack(side="left", padx=2)
            tk.Button(btn_r, text=t(ui, "saetze_bear_loeschen"), font=("Arial", 10, "bold"),
                      bg=CLR["red"], fg="white", relief="flat", padx=7, pady=3,
                      cursor="hand2",
                      command=lambda idx=i: self._satz_loeschen(idx)).pack(side="left", padx=2)

    def _satz_aendern(self, index):
        ui, ls = self.ui, self.ls
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)
        liste  = saetze_laden(ls)
        satz   = liste[index]

        popup = tk.Toplevel(self.root)
        popup.title(t(ui, "saetze_bear_aendern_titel"))
        popup.resizable(False, False)
        popup.configure(bg=CLR["popup_bg"])
        popup.grab_set()

        def lbl(txt):
            tk.Label(popup, text=txt, font=("Arial", 11, "bold"),
                     bg=CLR["popup_bg"], fg=CLR["text"]).pack(pady=(14, 4), padx=30, anchor="w")

        def text_kasten(parent, initial_value=""):
            outer = tk.Frame(parent, bg=CLR["border"])
            outer.pack(fill="x", padx=30, pady=(0, 4))
            inner = tk.Frame(outer, bg=CLR["entry_bg"])
            inner.pack(fill="x", padx=2, pady=2)
            txt = tk.Text(inner, font=("Arial", 13, "bold"), height=3, wrap="word",
                          fg=CLR["entry_fg"], bg=CLR["entry_bg"],
                          insertbackground=CLR["entry_ins"],
                          bd=0, relief="flat", highlightthickness=0, padx=8, pady=6)
            txt.pack(fill="x")
            txt.insert("1.0", initial_value)

            def on_focus_in(e):
                outer.config(bg=CLR["blue"])
            def on_focus_out(e):
                outer.config(bg=CLR["border"])

            txt.bind("<FocusIn>",  on_focus_in)
            txt.bind("<FocusOut>", on_focus_out)
            return txt

        lbl(f"{mutter}:")
        ein_a = text_kasten(popup, satz.get("nativ", ""))

        lbl(f"{lsname}:")
        ein_b = text_kasten(popup, satz.get("lern", ""))

        lbl(t(ui, "saetze_bear_audio"))
        satz_audio_var = tk.StringVar(value=satz.get("audio", ""))
        af = tk.Frame(popup, bg=CLR["popup_bg"])
        af.pack(fill="x", padx=30, pady=(0, 6))

        def kurz_s(pfad):
            return os.path.basename(pfad) if pfad else "(keine)"

        satz_audio_lbl = tk.Label(af, text=kurz_s(satz_audio_var.get()),
                                  font=("Arial", 9, "bold"), bg=CLR["popup_bg"], fg=CLR["text"],
                                  anchor="w", width=28)
        satz_audio_lbl.pack(side="left")

        def waehle_satz_audio():
            pfad = filedialog.askopenfilename(
                title="MP3 wählen",
                initialdir=AUDIO_DIR,
                filetypes=[("MP3-Dateien", "*.mp3"), ("Alle Dateien", "*.*")])
            if pfad:
                name = os.path.basename(pfad)
                satz_audio_var.set(name)
                satz_audio_lbl.config(text=name)

        tk.Button(af, text=t(ui, "saetze_bear_audio_btn"), font=("Arial", 10, "bold"),
                  bg=CLR["blue"], fg="white", relief="flat", padx=8, pady=3,
                  cursor="hand2", command=waehle_satz_audio).pack(side="left", padx=6)

        def speichern():
            a = ein_a.get("1.0", tk.END).strip()
            b = ein_b.get("1.0", tk.END).strip()
            if a and b:
                liste[index] = {"nativ": a, "lern": b, "audio": satz_audio_var.get().strip()}
                saetze_speichern(ls, liste)
                popup.destroy()
                self._saetze_bear_aufbauen()

        row = tk.Frame(popup, bg=CLR["popup_bg"])
        row.pack(pady=(12, 20))
        tk.Button(row, text=t(ui, "saetze_bear_speichern"), font=("Arial", 11, "bold"),
                  bg=CLR["purple"], fg="white", relief="flat", padx=14, pady=6,
                  cursor="hand2", command=speichern).pack(side="left", padx=6)
        tk.Button(row, text=t(ui, "saetze_bear_abbruch"), font=("Arial", 11, "bold"),
                  bg=CLR["gray"], fg=CLR["text"], relief="flat", padx=12, pady=6,
                  cursor="hand2", command=popup.destroy).pack(side="left", padx=6)

        self.root.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width()  // 2 - 220
        y = self.root.winfo_y() + self.root.winfo_height() // 2 - 220
        popup.geometry(f"440x480+{x}+{y}")
        ein_a.focus()

    def _satz_loeschen(self, index):
        ui, ls = self.ui, self.ls
        liste = saetze_laden(ls)
        wort  = liste[index].get("nativ", "")
        if messagebox.askyesno(t(ui, "saetze_bear_loeschen_titel"), t(ui, "saetze_bear_loeschen_frage", w=wort)):
            liste.pop(index)
            saetze_speichern(ls, liste)
            self._saetze_bear_aufbauen()

    def zeige_saetze_eintragen(self):
        self.clear()
        self.root.geometry("500x620")
        ui, ls = self.ui, self.ls
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)

        tk.Label(self.root, text=t(ui, "saetze_ein_titel"), font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(22, 2))
        tk.Label(self.root, text=t(ui, "saetze_ein_hinweis"),
                 font=("Arial", 10), bg=CLR["bg"], fg=CLR["sub"]).pack(pady=(0, 14))

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=30, fill="x", pady=(0, 10))
        tk.Label(f_a, text=mutter.upper(), font=("Arial", 11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.satz_ein_a = tk.Text(f_a, font=("Arial", 14, "bold"), height=3, wrap="word",
                                   fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                                   bg=CLR["entry_bg"], padx=10,
                                   insertbackground=CLR["entry_ins"])
        self.satz_ein_a.pack(fill="x", padx=6, pady=(0, 10))

        f_b = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_b.pack(padx=30, fill="x", pady=(0, 10))
        tk.Label(f_b, text=lsname.upper(), font=("Arial", 11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.satz_ein_b = tk.Text(f_b, font=("Arial", 14, "bold"), height=3, wrap="word",
                                   fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                                   bg=CLR["entry_bg"], padx=10,
                                   insertbackground=CLR["entry_ins"])
        self.satz_ein_b.pack(fill="x", padx=6, pady=(0, 10))

        f_audio_s = tk.Frame(self.root, bg=CLR["white"],
                             highlightbackground=CLR["card_border"], highlightthickness=2)
        f_audio_s.pack(padx=30, fill="x", pady=(0, 10))
        tk.Label(f_audio_s, text="🎵  AUDIO (optional)", font=("Arial", 11, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(8, 2))
        self.satz_audio_var = tk.StringVar(value="")
        saf_row = tk.Frame(f_audio_s, bg=CLR["white"])
        saf_row.pack(fill="x", padx=12, pady=(0, 10))
        self.satz_audio_lbl = tk.Label(saf_row, text="(keine)",
                                       font=("Arial", 10), bg=CLR["white"],
                                       fg=CLR["sub"], anchor="w")
        self.satz_audio_lbl.pack(side="left", fill="x", expand=True)

        def waehle_satz_ein_audio():
            pfad = filedialog.askopenfilename(
                title="MP3-Datei wählen",
                initialdir=AUDIO_DIR,
                filetypes=[("MP3-Dateien", "*.mp3"), ("Alle Dateien", "*.*")])
            if pfad:
                name = os.path.basename(pfad)
                self.satz_audio_var.set(name)
                self.satz_audio_lbl.config(text=name, fg=CLR["green"])

        def satz_audio_loeschen():
            self.satz_audio_var.set("")
            self.satz_audio_lbl.config(text="(keine)", fg=CLR["sub"])

        tk.Button(saf_row, text="📂 Wählen", font=("Arial", 10, "bold"),
                  bg=CLR["blue"], fg="white", relief="flat", padx=8, pady=3,
                  cursor="hand2", command=waehle_satz_ein_audio).pack(side="left", padx=(6, 2))
        tk.Button(saf_row, text="✕", font=("Arial", 10, "bold"),
                  bg=CLR["red"], fg="white", relief="flat", padx=6, pady=3,
                  cursor="hand2", command=satz_audio_loeschen).pack(side="left", padx=(2, 0))

        self.lbl_satz_status = tk.Label(self.root, text="", font=("Arial", 11),
                                        bg=CLR["bg"], fg="#27ae60")
        self.lbl_satz_status.pack(pady=(0, 8))

        row = make_frame(self.root)
        row.pack()
        tk.Button(row, text=t(ui, "speichern"), font=("Arial", 12, "bold"),
                  bg=CLR["blue"], fg="white", relief="flat", padx=18, pady=8,
                  cursor="hand2", command=self._satz_speichern).pack(side="left", padx=6)
        tk.Button(row, text=t(ui, "zurueck"), font=("Arial", 12, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=14, pady=8,
                  cursor="hand2", command=self.zeige_saetze_menue).pack(side="left", padx=6)

        self.satz_ein_a.focus()

    def _satz_speichern(self):
        ui, ls = self.ui, self.ls
        a = self.satz_ein_a.get("1.0", tk.END).strip()
        b = self.satz_ein_b.get("1.0", tk.END).strip()
        if not a or not b:
            self.lbl_satz_status.config(text=t(ui, "saetze_ein_fehler"), fg=CLR["red"])
            return
        audio = self.satz_audio_var.get().strip() if hasattr(self, 'satz_audio_var') else ""
        liste = saetze_laden(ls)
        liste.append({"nativ": a, "lern": b, "audio": audio})
        saetze_speichern(ls, liste)
        self.lbl_satz_status.config(text=t(ui, "saetze_ein_ok"), fg="#27ae60")
        self.satz_ein_a.delete("1.0", tk.END)
        self.satz_ein_b.delete("1.0", tk.END)
        self.satz_audio_var.set("")
        self.satz_audio_lbl.config(text="(keine)", fg=CLR["sub"])
        self.satz_ein_a.focus()

    def zeige_saetze_test(self, umgekehrt=False):
        ui, ls = self.ui, self.ls
        saetze = saetze_laden(ls)
        if not saetze:
            messagebox.showinfo(t(ui, "saetze_kein_titel"), t(ui, "saetze_kein"))
            return

        self._session_starten()
        self.clear()
        self.root.geometry("780x760")
        lsname = langname(ui, ls)
        mutter = muttersprache_label(ui)

        self.satz_liste      = saetze[:]
        random.shuffle(self.satz_liste)
        self.satz_index      = 0
        self.satz_richtig_w  = 0
        self.satz_falsch_w   = 0
        self.satz_versuche   = 0
        self.satz_max_vers   = 5
        self.satz_bereits_richtig = []
        self.satz_umgekehrt  = umgekehrt
        self.satz_audio_gespielt = False
        self.xp_multiplikator    = 1.5 if hat_freischaltung("xp_multiplikator") else 1.0
        self.streak_bonus_aktiv  = hat_freischaltung("streak_bonus")

        if umgekehrt:
            label_frage   = nativname(ls).upper()
            label_eingabe = mutter.upper()
            self.satz_key_frage   = "lern"
            self.satz_key_loesung = "nativ"
        else:
            label_frage   = mutter.upper()
            label_eingabe = nativname(ls).upper()
            self.satz_key_frage   = "nativ"
            self.satz_key_loesung = "lern"

        tk.Label(self.root, text=t(ui, "saetze_test_titel"), font=("Arial", 16, "bold"),
                 bg=CLR["bg"], fg=CLR["text"]).pack(pady=(14, 2))
        tk.Label(self.root, text="🔴 Audio PFLICHT vor Weiter!",
                 font=("Arial", 10, "bold"), bg=CLR["bg"], fg=CLR["red"]).pack(pady=(0, 4))

        info_row = make_frame(self.root)
        info_row.pack()
        self.lbl_satz_nr = tk.Label(info_row, text="", font=("Arial", 11),
                                    bg=CLR["bg"], fg=CLR["sub"])
        self.lbl_satz_nr.pack(side="left", padx=8)
        self.lbl_satz_vers = tk.Label(info_row, text="", font=("Arial", 11, "bold"),
                                      bg=CLR["bg"], fg=CLR["orange"])
        self.lbl_satz_vers.pack(side="left", padx=8)

        f_a = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_a.pack(padx=12, fill="x", pady=(6, 6))
        tk.Label(f_a, text=label_frage, font=("Arial", 10, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(6, 2))
        self.lbl_satz_frage = tk.Label(f_a, text="", font=("Arial", 15, "bold"),
                                        bg=CLR["white"], fg=CLR["text"],
                                        wraplength=700, justify="left")
        self.lbl_satz_frage.pack(padx=12, pady=(0, 10))

        f_b = tk.Frame(self.root, bg=CLR["white"],
                       highlightbackground=CLR["card_border"], highlightthickness=2)
        f_b.pack(padx=12, fill="x", pady=(0, 4))
        tk.Label(f_b, text=label_eingabe, font=("Arial", 10, "bold"),
                 bg=CLR["white"], fg=CLR["text"]).pack(pady=(6, 2))
        self.satz_eingabe = tk.Text(f_b, font=("Arial", 14, "bold"), height=3, wrap="word",
                                    fg=CLR["entry_fg"], bd=0, highlightthickness=0,
                                    bg=CLR["entry_bg"], padx=10,
                                    insertbackground=CLR["entry_ins"])
        self.satz_eingabe.pack(fill="x", padx=6, pady=(0, 10))

        # Sonderzeichen wenn Deutsch einzugeben (aus Sprachauswahl-Popup oder umgekehrt)
        zeige_sz = getattr(self, '_satz_schreibe_deutsch', umgekehrt)
        if zeige_sz:
            sz_row = make_frame(self.root)
            sz_row.pack(pady=(0, 4))
            for zeichen in ["ß", "Ü", "Ä", "Ö"]:
                tk.Button(sz_row, text=zeichen, font=("Arial", 15, "bold"),
                          bg=CLR["blue"], fg="white", relief="flat",
                          padx=16, pady=6, cursor="hand2",
                          command=lambda z=zeichen: self._satz_sonderzeichen(z)).pack(side="left", padx=4)

        fb_outer = tk.Frame(self.root, bg=CLR["white"],
                            highlightbackground=CLR["card_border"], highlightthickness=2)
        fb_outer.pack(padx=12, fill="x", pady=(0, 4))
        tk.Label(fb_outer, text=t(ui, "satz_fb_titel"),
                 font=("Arial", 9, "bold"), bg=CLR["white"], fg=CLR["sub"]).pack(pady=(6, 2))
        fb_scroll_frame = tk.Frame(fb_outer, bg=CLR["white"])
        fb_scroll_frame.pack(fill="x", padx=6, pady=(0, 6))
        fb_canvas = tk.Canvas(fb_scroll_frame, bg=CLR["white"], highlightthickness=0, height=110)
        fb_sb = tk.Scrollbar(fb_scroll_frame, orient="horizontal", command=fb_canvas.xview)
        fb_canvas.configure(xscrollcommand=fb_sb.set)
        fb_sb.pack(side="bottom", fill="x")
        fb_canvas.pack(side="top", fill="x")
        self.fb_canvas = fb_canvas
        self.fb_inner = tk.Frame(fb_canvas, bg=CLR["white"])
        fb_canvas.create_window((0, 0), window=self.fb_inner, anchor="nw")
        self.fb_inner.bind("<Configure>",
            lambda e: fb_canvas.configure(scrollregion=fb_canvas.bbox("all")))

        row = make_frame(self.root)
        row.pack(pady=6)
        self.btn_satz_audio = tk.Button(row, text="▶  Audio PFLICHT",
                                         font=("Arial", 11, "bold"),
                                         bg=CLR["red"], fg="white", relief="flat",
                                         padx=10, pady=8, cursor="hand2",
                                         command=self._satz_play_audio)
        self.btn_satz_audio.pack(side="left", padx=3)
        self.btn_satz_pruefen = tk.Button(row, text=t(ui, "satz_test_prufen"),
                                          font=("Arial", 12, "bold"),
                                          bg="#d35400", fg="white", relief="flat",
                                          padx=16, pady=8, cursor="hand2",
                                          command=self._satz_pruefen)
        self.btn_satz_pruefen.pack(side="left", padx=3)
        self.btn_satz_weiter = tk.Button(row, text=t(ui, "weiter"),
                                          font=("Arial", 12, "bold"),
                                          bg=CLR["gray"], fg=CLR["sub"], relief="flat",
                                          padx=16, pady=8, cursor="hand2",
                                          command=self._satz_weiter,
                                          state="disabled")
        self.btn_satz_weiter.pack(side="left", padx=3)
        tk.Button(row, text=t(ui, "zurueck"), font=("Arial", 11, "bold"),
                  bg=CLR["back_bg"], fg=CLR["back_fg"], relief="flat", padx=10, pady=8,
                  cursor="hand2", command=self._satz_zurueck).pack(side="left", padx=3)

        self.root.bind("<Return>", lambda e: self._satz_pruefen()
                       if self.btn_satz_pruefen["state"] == "normal" else None)
        self._satz_naechste()

    def _satz_fb_aufbauen(self, w_loesung, w_antwort):
        for w in self.fb_inner.winfo_children():
            w.destroy()

        for i, soll in enumerate(w_loesung):
            bereits_ok = i in self.satz_bereits_richtig
            ist = w_antwort[i] if i < len(w_antwort) else ""
            korrekt = bereits_ok or (ist == soll)

            if i > 0:
                tk.Label(self.fb_inner, text="│", font=("Arial", 18),
                         bg=CLR["white"], fg=CLR["sub"]).pack(side="left", padx=1)

            kachel = tk.Frame(self.fb_inner, bg=CLR["white"])
            kachel.pack(side="left", padx=3, pady=6)

            if korrekt:
                box = tk.Frame(kachel, bg=CLR["white"],
                               highlightbackground="#27ae60", highlightthickness=2)
                box.pack()
                tk.Label(box, text="✅", font=("Arial", 10), bg=CLR["white"]).pack(pady=(4, 0))
                tk.Label(box, text=soll, font=("Arial", 13, "bold"),
                         bg=CLR["white"], fg="#27ae60").pack(padx=10, pady=(2, 6))
            else:
                box = tk.Frame(kachel, bg=CLR["white"],
                               highlightbackground=CLR["red"], highlightthickness=2)
                box.pack()
                tk.Label(box, text="❌", font=("Arial", 10), bg=CLR["white"]).pack(pady=(4, 0))
                tk.Label(box, text="?", font=("Arial", 13, "bold"),
                         bg=CLR["white"], fg="#c0392b").pack(padx=14, pady=(2, 6))

        for j in range(len(w_loesung), len(w_antwort)):
            tk.Label(self.fb_inner, text="│", font=("Arial", 18),
                     bg=CLR["white"], fg=CLR["sub"]).pack(side="left", padx=1)
            kachel = tk.Frame(self.fb_inner, bg=CLR["white"])
            kachel.pack(side="left", padx=3, pady=6)
            box = tk.Frame(kachel, bg=CLR["white"],
                           highlightbackground=CLR["red"], highlightthickness=2)
            box.pack()
            tk.Label(box, text="❌ extra", font=("Arial", 9),
                     bg=CLR["white"], fg=CLR["red"]).pack(padx=6, pady=(4, 0))
            tk.Label(box, text=w_antwort[j], font=("Arial", 12, "bold"),
                     bg=CLR["white"], fg=CLR["red"]).pack(padx=8, pady=(0, 6))

        self.fb_canvas.update_idletasks()
        self.fb_canvas.configure(scrollregion=self.fb_canvas.bbox("all"))

    def _satz_sonderzeichen(self, z):
        try:
            self.satz_eingabe.insert(tk.INSERT, z)
        except Exception:
            self.satz_eingabe.insert(tk.END, z)
        self.satz_eingabe.focus()

    def _satz_play_audio(self):
        if not PYGAME_OK:
            messagebox.showinfo("Audio", "pygame nicht installiert.\npip install pygame")
            return
        if self.satz_index >= len(self.satz_liste):
            return
        satz      = self.satz_liste[self.satz_index]
        dateiname = satz.get("audio", "")
        pfad      = audio_pfad(dateiname)
        if pfad and os.path.exists(pfad):
            try:
                pygame.mixer.music.load(pfad)
                pygame.mixer.music.play()
                self.satz_audio_gespielt = True
                self.btn_satz_audio.config(bg="#16a085", text="▶  Audio ✓")
            except Exception as e:
                messagebox.showerror("Audio", str(e))
        else:
            self.satz_audio_gespielt = True
            self.btn_satz_audio.config(bg=CLR["sub"], text="▶  Kein Audio")
            messagebox.showinfo("Audio",
                f"Kein Audio für diesen Satz.\n\nAudio-Dateien bitte in den Ordner:\n{AUDIO_DIR}")
        # Weiter-Button freischalten wenn Antwort bereits bewertet wurde
        if self.satz_audio_gespielt and self.btn_satz_pruefen["state"] == "disabled":
            self.btn_satz_weiter.config(state="normal", bg=CLR["green"], fg="white",
                                         text=t(self.ui, "weiter"))
            self.btn_satz_weiter.focus()

    def _satz_naechste(self):
        ui = self.ui
        if self.satz_index >= len(self.satz_liste):
            self._satz_abschluss()
            return
        satz = self.satz_liste[self.satz_index]
        self.satz_versuche = 0
        self.satz_bereits_richtig = []
        self.satz_audio_gespielt = False
        self.lbl_satz_nr.config(
            text=t(ui, "test_frage", i=self.satz_index+1, n=len(self.satz_liste)))
        self.lbl_satz_vers.config(
            text=t(ui, "satz_vers_uebrig", v=self.satz_max_vers - self.satz_versuche))
        self.lbl_satz_frage.config(text=satz[self.satz_key_frage])
        for w in self.fb_inner.winfo_children():
            w.destroy()
        self.satz_eingabe.config(state="normal")
        self.satz_eingabe.delete("1.0", tk.END)
        self.btn_satz_pruefen.config(state="normal")
        self.btn_satz_weiter.config(state="disabled", bg=CLR["gray"], fg=CLR["sub"])
        self.btn_satz_audio.config(bg=CLR["red"], text="▶  Audio PFLICHT")
        self.satz_eingabe.focus()

    def _satz_pruefen(self):
        if self.btn_satz_pruefen["state"] == "disabled":
            return
        ui  = self.ui
        satz     = self.satz_liste[self.satz_index]
        loesung  = satz[self.satz_key_loesung]
        antwort  = self.satz_eingabe.get("1.0", tk.END).strip()

        w_loesung = loesung.split()
        w_antwort = antwort.split()

        richtig_count = sum(1 for i, soll in enumerate(w_loesung)
                            if i < len(w_antwort) and w_antwort[i] == soll)
        falsch_count  = len(w_loesung) - richtig_count
        falsch_count += max(0, len(w_antwort) - len(w_loesung))

        for i, soll in enumerate(w_loesung):
            if i not in self.satz_bereits_richtig:
                ist = w_antwort[i] if i < len(w_antwort) else ""
                if ist == soll:
                    self.satz_bereits_richtig.append(i)

        self._satz_fb_aufbauen(w_loesung, w_antwort)

        self.satz_versuche += 1
        verbleibend = self.satz_max_vers - self.satz_versuche

        alle_richtig = (falsch_count == 0)
        versuche_vorbei = (self.satz_versuche >= self.satz_max_vers)

        if alle_richtig or versuche_vorbei:
            self.satz_richtig_w += richtig_count
            self.satz_falsch_w  += falsch_count

            xp_g = int(richtig_count * 2 * self.xp_multiplikator)
            xp_v = falsch_count
            s = stats_laden()
            s["richtig"]  = s.get("richtig", 0) + richtig_count
            s["falsch"]   = s.get("falsch",  0) + falsch_count
            s["level_xp"] = max(0, s.get("level_xp", 0) + xp_g - xp_v)
            neu = check_neue_freischaltungen(s, ui=self.ui)
            stats_speichern(s)
            if neu:
                self.root.after(800, lambda: self._zeige_freischaltung_popup(neu, s))

            if alle_richtig:
                e_suf = "en" if self.satz_versuche > 1 else ""
                self.lbl_satz_vers.config(
                    text=t(ui, "satz_vers_perfekt", v=self.satz_versuche, e=e_suf),
                    fg="#27ae60")
            else:
                self.lbl_satz_vers.config(
                    text=t(ui, "satz_vers_auf"),
                    fg=CLR["red"])
                for w in self.fb_inner.winfo_children():
                    w.destroy()
                for i, soll in enumerate(w_loesung):
                    if i > 0:
                        tk.Label(self.fb_inner, text="│", font=("Arial", 18),
                                 bg=CLR["white"], fg=CLR["sub"]).pack(side="left", padx=1)
                    kachel = tk.Frame(self.fb_inner, bg=CLR["white"])
                    kachel.pack(side="left", padx=3, pady=6)
                    ist = w_antwort[i] if i < len(w_antwort) else ""
                    korrekt = (ist == soll)
                    bg_k = CLR["white"]
                    rand  = "#27ae60" if korrekt else "#f39c12"
                    icon  = "✅" if korrekt else "💡"
                    box = tk.Frame(kachel, bg=bg_k,
                                   highlightbackground=rand, highlightthickness=2)
                    box.pack()
                    tk.Label(box, text=icon, font=("Arial", 10), bg=bg_k).pack(pady=(4, 0))
                    tk.Label(box, text=soll, font=("Arial", 13, "bold"),
                             bg=bg_k, fg=rand).pack(padx=10, pady=(2, 6))
                self.fb_canvas.update_idletasks()
                self.fb_canvas.configure(scrollregion=self.fb_canvas.bbox("all"))

            self.satz_eingabe.config(state="disabled")
            self.btn_satz_pruefen.config(state="disabled")
            if self.satz_audio_gespielt:
                self.btn_satz_weiter.config(state="normal", bg=CLR["green"], fg="white",
                                             text=t(self.ui, "weiter"))
                self.btn_satz_weiter.focus()
            else:
                self.btn_satz_weiter.config(state="disabled", bg=CLR["red"], fg="white",
                                             text="▶ Audio PFLICHT → dann Weiter")
        else:
            e_suf = "e" if verbleibend != 1 else ""
            self.lbl_satz_vers.config(
                text=t(ui, "satz_vers_fehler", f=falsch_count, v=verbleibend, e=e_suf),
                fg=CLR["orange"])
            self.satz_eingabe.delete("1.0", tk.END)
            self.satz_eingabe.focus()

    def _satz_weiter(self):
        if self.btn_satz_weiter["state"] == "disabled":
            return
        if not self.satz_audio_gespielt:
            messagebox.showwarning("Audio Pflicht!",
                "Bitte zuerst das Audio abspielen!\n(▶ Audio PFLICHT Button)")
            return
        self.btn_satz_weiter.config(text=t(self.ui, "weiter"))
        self.satz_index += 1
        self._satz_naechste()

    def _satz_zurueck(self):
        self._session_beenden()
        self.zeige_hauptmenue()

    def _satz_abschluss(self):
        self._session_beenden()
        ui  = self.ui
        r   = self.satz_richtig_w
        f   = self.satz_falsch_w
        g   = r + f
        p   = int(r / g * 100) if g else 0
        messagebox.showinfo("🎉", t(ui, "saetze_ergebnis", r=r, g=g, p=p, f=f))
        self.zeige_saetze_richtung_test()


# ============================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
