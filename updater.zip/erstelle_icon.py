"""Erstellt heart.ico im Vokabeln-Ordner. Einmal ausfuehren, dann loeschen/ignorieren."""
import math
import os
from PIL import Image, ImageDraw

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
size = 256
img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)
red = (230, 30, 60, 255)

def heart_points(cx, cy, scale):
    pts = []
    for t in range(0, 628):
        a = t / 100.0
        x = 16 * math.sin(a) ** 3
        y = 13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a)
        pts.append((cx + x * scale, cy - y * scale))
    return pts

pts = heart_points(size / 2, size / 2 + 10, 9.5)
draw.polygon(pts, fill=red)

ico_path = os.path.join(BASE_DIR, "heart.ico")
img.save(ico_path, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print(f"Icon erstellt: {ico_path}")
